import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';

export default function MainLayout() {
  return (
    <div className="min-h-screen" style={{ background: '#F0F2F8' }}>
      <Sidebar />
      <div className="lg:mr-[240px] transition-all duration-300">
        <Header />
        <main className="p-4 md:p-6 pb-24 lg:pb-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
