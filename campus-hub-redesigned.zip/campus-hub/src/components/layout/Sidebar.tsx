import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Home, Car, MessageCircle, BookOpen, Users,
  Bell, Shield, X, Menu, GraduationCap,
  ChevronLeft, LogOut,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

const navItems = [
  { id: 'home',         label: 'الرئيسية',    icon: Home,          path: '/home' },
  { id: 'rides',        label: 'الخطوط',       icon: Car,           path: '/rides' },
  { id: 'chat',         label: 'الدردشة',      icon: MessageCircle, path: '/chat' },
  { id: 'resources',   label: 'المصادر',       icon: BookOpen,      path: '/resources' },
  { id: 'community',   label: 'المجتمع',       icon: Users,         path: '/community' },
];

const bottomItems = [
  { id: 'notifications', label: 'الإشعارات', icon: Bell,   path: '/notifications', badge: true },
  { id: 'admin',         label: 'الإدارة',    icon: Shield, path: '/admin' },
];

export default function Sidebar() {
  const location = useLocation();
  const { user, unreadCount } = useApp();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {/* Mobile FAB */}
      <button
        onClick={() => setIsMobileOpen(true)}
        className="lg:hidden fixed bottom-6 right-4 z-50 w-12 h-12 flex items-center justify-center rounded-2xl shadow-lg text-white"
        style={{ background: 'linear-gradient(135deg,#4F46E5,#7C3AED)' }}
      >
        <Menu size={22} />
      </button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40"
          style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          sidebar fixed top-0 right-0 h-full z-50 flex flex-col
          transition-all duration-300 ease-in-out
          ${isCollapsed ? 'w-[72px]' : 'w-[240px]'}
          ${isMobileOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Logo */}
        <div className="flex items-center justify-between px-4 py-5 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          {!isCollapsed && (
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: 'linear-gradient(135deg,rgba(255,255,255,0.25),rgba(255,255,255,0.1))', border: '1px solid rgba(255,255,255,0.2)' }}>
                <GraduationCap size={20} className="text-white" />
              </div>
              <div>
                <p className="text-white font-bold text-base leading-tight">Campus Hub</p>
                <p className="text-xs leading-tight" style={{ color: 'rgba(255,255,255,0.4)' }}>منصة الطلاب</p>
              </div>
            </div>
          )}
          {isCollapsed && (
            <div className="w-9 h-9 rounded-xl flex items-center justify-center mx-auto"
              style={{ background: 'linear-gradient(135deg,rgba(255,255,255,0.25),rgba(255,255,255,0.1))', border: '1px solid rgba(255,255,255,0.2)' }}>
              <GraduationCap size={20} className="text-white" />
            </div>
          )}
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={() => { setIsCollapsed(!isCollapsed); setIsMobileOpen(false); }}
              className="p-1.5 rounded-lg lg:flex hidden items-center justify-center transition-colors"
              style={{ color: 'rgba(255,255,255,0.5)' }}
              onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.08)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            >
              <ChevronLeft size={16} className={`transition-transform duration-300 ${isCollapsed ? 'rotate-180' : ''}`} />
            </button>
            <button
              onClick={() => setIsMobileOpen(false)}
              className="p-1.5 rounded-lg lg:hidden flex items-center justify-center"
              style={{ color: 'rgba(255,255,255,0.5)' }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Nav Main */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto space-y-1">
          {!isCollapsed && (
            <p className="px-3 mb-2 text-xs font-600 uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.3)', fontSize: '0.68rem' }}>
              القائمة الرئيسية
            </p>
          )}
          {navItems.map(item => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <Link
                key={item.id}
                to={item.path}
                onClick={() => setIsMobileOpen(false)}
                className={`nav-item ${active ? 'active' : ''} ${isCollapsed ? 'justify-center px-0' : ''}`}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon size={19} className="flex-shrink-0" />
                {!isCollapsed && <span>{item.label}</span>}
              </Link>
            );
          })}

          {/* Divider */}
          <div className="my-3" style={{ height: '1px', background: 'rgba(255,255,255,0.07)' }} />

          {!isCollapsed && (
            <p className="px-3 mb-2 text-xs font-600 uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.3)', fontSize: '0.68rem' }}>
              أخرى
            </p>
          )}

          {bottomItems.map(item => {
            const Icon = item.icon;
            const active = isActive(item.path);
            const badgeCount = item.badge ? unreadCount : 0;
            return (
              <Link
                key={item.id}
                to={item.path}
                onClick={() => setIsMobileOpen(false)}
                className={`nav-item ${active ? 'active' : ''} ${isCollapsed ? 'justify-center px-0' : ''}`}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon size={19} className="flex-shrink-0" />
                {!isCollapsed && <span className="flex-1">{item.label}</span>}
                {!isCollapsed && badgeCount > 0 && (
                  <span className="nav-badge">{badgeCount}</span>
                )}
                {isCollapsed && badgeCount > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* User Section */}
        {user && (
          <div className="px-3 py-4 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
            <div className={`flex items-center gap-3 p-2 rounded-xl transition-colors cursor-pointer ${isCollapsed ? 'justify-center' : ''}`}
              style={{}}
              onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.07)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            >
              <div className="avatar w-9 h-9 text-sm flex-shrink-0">
                {user.name.charAt(0)}
              </div>
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <p className="text-white font-semibold text-sm truncate leading-tight">{user.name}</p>
                  <p className="text-xs truncate leading-tight" style={{ color: 'rgba(255,255,255,0.4)' }}>{user.university}</p>
                </div>
              )}
              {!isCollapsed && (
                <button className="p-1 rounded-lg transition-colors flex-shrink-0"
                  style={{ color: 'rgba(255,255,255,0.35)' }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.8)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.35)')}
                >
                  <LogOut size={15} />
                </button>
              )}
            </div>
          </div>
        )}
      </aside>
    </>
  );
}
