import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, Search } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export default function Header() {
  const { user, unreadCount } = useApp();
  const [searchFocused, setSearchFocused] = useState(false);

  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'صباح الخير';
    if (h < 17) return 'مساء الخير';
    return 'مساء النور';
  };

  return (
    <header className="top-header sticky top-0 z-30">
      <div className="flex items-center gap-4 px-5 py-3">

        {/* Greeting (hidden on mobile) */}
        <div className="hidden md:block flex-shrink-0">
          <p className="text-xs font-medium" style={{ color: '#94A3B8' }}>{getGreeting()}</p>
          <p className="font-bold text-sm" style={{ color: '#1E293B' }}>{user?.name ?? 'الطالب'} 👋</p>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-lg">
          <div className="search-bar">
            <Search size={17} style={{ color: searchFocused ? '#4F46E5' : '#94A3B8', flexShrink: 0, transition: 'color 0.2s' }} />
            <input
              placeholder="ابحث عن طالب، مادة، خط..."
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setSearchFocused(false)}
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 flex-shrink-0">

          {/* Bell */}
          <Link
            to="/notifications"
            className="relative flex items-center justify-center w-10 h-10 rounded-xl transition-all"
            style={{ background: '#F1F5F9', color: '#64748B' }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#E2E8F0'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = '#F1F5F9'; }}
          >
            <Bell size={20} />
            {unreadCount > 0 && (
              <span
                className="absolute -top-0.5 -right-0.5 w-5 h-5 text-white text-xs font-bold rounded-full flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg,#EF4444,#DC2626)', fontSize: '0.68rem', boxShadow: '0 2px 6px rgba(239,68,68,0.4)' }}
              >
                {unreadCount}
              </span>
            )}
          </Link>

          {/* Avatar */}
          {user && (
            <Link to="/admin" className="flex items-center gap-2.5 py-1 px-1 rounded-xl transition-all"
              style={{ color: '#1E293B' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#F1F5F9'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
            >
              <div className="avatar w-8 h-8 text-sm">{user.name.charAt(0)}</div>
              <span className="hidden sm:block text-sm font-semibold">{user.name}</span>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
