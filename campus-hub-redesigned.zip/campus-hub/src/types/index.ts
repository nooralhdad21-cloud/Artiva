export interface User {
  id: string;
  name: string;
  gender: 'male' | 'female';
  university: string;
  universityId: string;
  college: string;
  department: string;
  departmentId: string;
  year: string;
  area: string;
  phone: string;
  avatar?: string;
  role: 'student' | 'driver' | 'admin';
  createdAt: string;
}

export interface Post {
  id: string;
  authorId: string;
  author: User;
  content: string;
  type: 'text' | 'image' | 'question' | 'announcement';
  images?: string[];
  likes: number;
  comments: Comment[];
  universityId: string;
  departmentId: string;
  tags?: string[];
  createdAt: string;
}

export interface Comment {
  id: string;
  authorId: string;
  author: User;
  content: string;
  createdAt: string;
}

export interface Ride {
  id: string;
  driverId: string;
  driver: User;
  from: string;
  to: string;
  time: string;
  date: string;
  seats: number;
  availableSeats: number;
  genderRestriction: 'all' | 'male' | 'female';
  price: number;
  status: 'active' | 'completed' | 'cancelled';
  passengers: string[];
  createdAt: string;
}

export interface Chat {
  id: string;
  type: 'individual' | 'group';
  name?: string;
  participants: User[];
  lastMessage?: Message;
  unreadCount: number;
  createdAt: string;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  sender: User;
  content: string;
  type: 'text' | 'image' | 'file' | 'location';
  attachments?: string[];
  read: boolean;
  createdAt: string;
}

export interface Resource {
  id: string;
  title: string;
  type: 'notes' | 'pdf' | 'video' | 'exam' | 'other';
  courseId: string;
  courseName: string;
  uploaderId: string;
  uploader: User;
  fileUrl: string;
  fileSize: string;
  downloads: number;
  createdAt: string;
}

export interface Course {
  id: string;
  name: string;
  departmentId: string;
  year: string;
}

export interface Notification {
  id: string;
  type: 'ride' | 'message' | 'resource' | 'community' | 'system';
  title: string;
  body: string;
  read: boolean;
  link?: string;
  createdAt: string;
}

export interface University {
  id: string;
  name: string;
  city: string;
  colleges: College[];
}

export interface College {
  id: string;
  name: string;
  universityId: string;
  departments: Department[];
}

export interface Department {
  id: string;
  name: string;
  collegeId: string;
  years: string[];
}