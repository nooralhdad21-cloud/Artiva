// Notification types and configuration
export type NotificationType =
  | 'ride'
  | 'message'
  | 'resource'
  | 'community'
  | 'system'
  | 'achievement'
  | 'badge'
  | 'warning'
  | 'reminder';

export type NotificationPriority = 'low' | 'normal' | 'high' | 'urgent';

export interface AppNotification {
  id: string;
  type: NotificationType;
  priority: NotificationPriority;
  title: string;
  body: string;
  data?: NotificationData;
  read: boolean;
  dismissed: boolean;
  createdAt: string;
  expiresAt?: string;
}

export interface NotificationData {
  link?: string;
  actionUrl?: string;
  imageUrl?: string;
  senderId?: string;
  contentId?: string;
  metadata?: Record<string, any>;
}

// Notification categories with icons
export const NOTIFICATION_CATEGORIES = {
  ride: { icon: '🚗', label: 'الخطوط', color: '#3B82F6' },
  message: { icon: '💬', label: 'الرسائل', color: '#10B981' },
  resource: { icon: '📚', label: 'المصادر', color: '#8B5CF6' },
  community: { icon: '👥', label: 'المجتمع', color: '#EC4899' },
  achievement: { icon: '🏆', label: 'إنجازات', color: '#F59E0B' },
  badge: { icon: '⭐', label: 'شارات', color: '#FFD700' },
  warning: { icon: '⚠️', label: 'تحذيرات', color: '#EF4444' },
  reminder: { icon: '🔔', label: 'تذكيرات', color: '#6366F1' },
  system: { icon: '⚙️', label: 'النظام', color: '#64748B' },
};

// Create notification helper
export function createNotification(
  type: NotificationType,
  priority: NotificationPriority,
  title: string,
  body: string,
  data?: NotificationData
): AppNotification {
  return {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    type,
    priority,
    title,
    body,
    data,
    read: false,
    dismissed: false,
    createdAt: new Date().toISOString(),
  };
}

// Notification templates for common scenarios
export const NOTIFICATION_TEMPLATES = {
  newRide: (rideInfo: { from: string; to: string; time: string }) =>
    createNotification(
      'ride',
      'high',
      'خط جديد متاح',
      `${rideInfo.from} → ${rideInfo.to} الساعة ${rideInfo.time}`,
      { actionUrl: '/rides' }
    ),

  rideReminder: (rideInfo: { from: string; time: string; date: string }) =>
    createNotification(
      'reminder',
      'high',
      'تذكير: رحلة غداً',
      `رحلة من ${rideInfo.from} الساعة ${rideInfo.time} في ${rideInfo.date}`,
      { actionUrl: '/rides' }
    ),

  newMessage: (sender: string, preview: string) =>
    createNotification(
      'message',
      'normal',
      `رسالة جديدة من ${sender}`,
      preview.length > 50 ? preview.substring(0, 50) + '...' : preview,
      { actionUrl: '/chat' }
    ),

  newResource: (courseName: string, resourceTitle: string) =>
    createNotification(
      'resource',
      'normal',
      'ملزمة جديدة',
      `${resourceTitle} - ${courseName}`,
      { actionUrl: '/resources' }
    ),

  newPost: (author: string, preview: string) =>
    createNotification(
      'community',
      'low',
      `منشور جديد من ${author}`,
      preview.length > 50 ? preview.substring(0, 50) + '...' : preview,
      { actionUrl: '/community' }
    ),

  commentOnPost: (commenter: string, postTitle: string) =>
    createNotification(
      'community',
      'normal',
      'تعليق جديد',
      `${commenter} علّق على: "${postTitle.substring(0, 30)}"`,
      { actionUrl: '/community' }
    ),

  badgeEarned: (badgeName: string, badgeIcon: string) =>
    createNotification(
      'badge',
      'high',
      '🎉 شارة جديدة!',
      `حصلت على شارة "${badgeName}" ${badgeIcon}`,
      { actionUrl: '/profile' }
    ),

  achievementUnlocked: (achievementName: string, reward: number) =>
    createNotification(
      'achievement',
      'high',
      '🏆 إنجاز جديد!',
      `أتممت "${achievementName}" - +${reward} نقطة`,
      { actionUrl: '/profile' }
    ),

  levelUp: (newLevel: number, levelTitle: string) =>
    createNotification(
      'achievement',
      'high',
      `🎉 ارتقيت للمستوى ${newLevel}!`,
      `أنت الآن "${levelTitle}" - واصل التقدم!`,
      { actionUrl: '/profile' }
    ),

  warning: (reason: string) =>
    createNotification(
      'warning',
      'urgent',
      '⚠️ تنبيه مهم',
      reason,
      { actionUrl: '/profile/settings' }
    ),

  contentReported: (contentType: string, status: 'approved' | 'rejected') =>
    createNotification(
      'system',
      status === 'rejected' ? 'high' : 'normal',
      status === 'rejected' ? 'تم حذف المحتوى' : 'تم الموافقة على المحتوى',
      status === 'rejected'
        ? `تم حذف ${contentType} المخالف`
        : `تم الموافقة على ${contentType}`,
      { actionUrl: '/community' }
    ),

  systemMaintenance: (message: string, duration: string) =>
    createNotification(
      'system',
      'high',
      '🔧 صيانة مجدولة',
      `${message} - المتوقع: ${duration}`,
      {}
    ),
};

// Notification preferences (user settings)
export interface NotificationPreferences {
  rideNotifications: boolean;
  messageNotifications: boolean;
  resourceNotifications: boolean;
  communityNotifications: boolean;
  achievementNotifications: boolean;
  marketingNotifications: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
  quietHoursStart?: string; // HH:mm format
  quietHoursEnd?: string;
}

export const DEFAULT_NOTIFICATION_PREFERENCES: NotificationPreferences = {
  rideNotifications: true,
  messageNotifications: true,
  resourceNotifications: true,
  communityNotifications: true,
  achievementNotifications: true,
  marketingNotifications: false,
  emailNotifications: false,
  pushNotifications: true,
};

// Group notifications by time
export function groupNotificationsByTime(notifications: AppNotification[]): {
  today: AppNotification[];
  yesterday: AppNotification[];
  thisWeek: AppNotification[];
  older: AppNotification[];
} {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);

  return {
    today: notifications.filter(n => new Date(n.createdAt) >= today),
    yesterday: notifications.filter(
      n => new Date(n.createdAt) >= yesterday && new Date(n.createdAt) < today
    ),
    thisWeek: notifications.filter(
      n => new Date(n.createdAt) >= weekAgo && new Date(n.createdAt) < yesterday
    ),
    older: notifications.filter(n => new Date(n.createdAt) < weekAgo),
  };
}

// Calculate unread count by type
export function calculateUnreadByType(notifications: AppNotification[]): Record<NotificationType, number> {
  const counts: Record<NotificationType, number> = {
    ride: 0,
    message: 0,
    resource: 0,
    community: 0,
    system: 0,
    achievement: 0,
    badge: 0,
    warning: 0,
    reminder: 0,
  };

  notifications
    .filter(n => !n.read && !n.dismissed)
    .forEach(n => {
      counts[n.type]++;
    });

  return counts;
}