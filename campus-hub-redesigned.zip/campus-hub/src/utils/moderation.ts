// Arabic profanity filter and content moderation
const arabicBadWords = [
  // Common profanity (censored)
  'كلب', 'حمار', 'أحمق', '白痴', 'دي',
  'حثالة', 'لقيط', 'زنديق', 'كافر', 'فاسق',
  'malaka', '3abe', 'da3wa', 'kafar',
  // Add more as needed
];

const englishBadWords = [
  'fuck', 'shit', 'bitch', 'asshole', 'damn',
  'crap', 'bastard', 'dick', 'pussy', 'cock',
  'hate', 'racist', 'nazi',
];

const spamKeywords = [
  'click here', 'free money', 'winner', 'congratulations',
  'act now', 'limited time', 'buy now', 'earn money',
  'casino', 'lottery', 'viagra', 'porn',
];

export interface ModerationResult {
  isClean: boolean;
  reason?: string;
  severity: 'none' | 'low' | 'medium' | 'high';
  suggestions?: string[];
}

export interface ImageModerationResult {
  isSafe: boolean;
  confidence: number;
  reason?: string;
}

// Text moderation
export function moderateText(text: string): ModerationResult {
  if (!text || text.trim().length === 0) {
    return { isClean: true, severity: 'none' };
  }

  const lowerText = text.toLowerCase();
  const words = lowerText.split(/\s+/);

  // Check for Arabic bad words
  for (const badWord of arabicBadWords) {
    if (lowerText.includes(badWord)) {
      return {
        isClean: false,
        reason: `يحتوي على كلمات غير لائقة`,
        severity: 'high',
        suggestions: ['يرجى استخدام لغة مناسبة'],
      };
    }
  }

  // Check for English bad words
  for (const badWord of englishBadWords) {
    if (lowerText.includes(badWord)) {
      return {
        isClean: false,
        reason: `يحتوي على محتوى غير مناسب`,
        severity: 'high',
        suggestions: ['يرجى استخدام لغة مناسبة'],
      };
    }
  }

  // Check for spam keywords
  let spamCount = 0;
  for (const keyword of spamKeywords) {
    if (lowerText.includes(keyword)) {
      spamCount++;
    }
  }

  if (spamCount >= 2) {
    return {
      isClean: false,
      reason: `قد يكون محتوى سبام`,
      severity: 'medium',
      suggestions: ['يرجى تجنب الكلمات التسويقية'],
    };
  }

  // Check for excessive caps (shouting)
  const capsRatio = (text.match(/[A-Z]/g) || []).length / text.length;
  if (capsRatio > 0.5 && text.length > 10) {
    return {
      isClean: true,
      severity: 'low',
      suggestions: ['تجنب الكتابة بالأحرف الكبيرة'],
    };
  }

  // Check for excessive punctuation
  const punctCount = (text.match(/[!؟.]{3,}/g) || []).length;
  if (punctCount > 2) {
    return {
      isClean: true,
      severity: 'low',
      suggestions: ['تجنب التكرار المفرط للت علامات'],
    };
  }

  return { isClean: true, severity: 'none' };
}

// Simulated image moderation (in production, use AI APIs)
export function moderateImage(_imageUrl: string): ImageModerationResult {
  // Simulate image check
  // In production, integrate with AWS Rekognition, Google Cloud Vision, or similar
  return {
    isSafe: true,
    confidence: 0.95,
  };
}

// Report content types
export type ReportType =
  | 'spam'
  | 'harassment'
  | 'inappropriate'
  | 'fake'
  | 'other';

export interface Report {
  id: string;
  reporterId: string;
  reportedUserId?: string;
  contentId: string;
  contentType: 'post' | 'comment' | 'message' | 'profile';
  type: ReportType;
  description: string;
  status: 'pending' | 'reviewed' | 'resolved' | 'dismissed';
  createdAt: string;
  resolvedAt?: string;
  resolvedBy?: string;
}

// Auto-moderation rules
export interface ModerationRule {
  id: string;
  name: string;
  condition: 'contains' | 'regex' | 'length' | 'frequency';
  pattern: string;
  action: 'warn' | 'flag' | 'block' | 'delete';
  severity: 'low' | 'medium' | 'high';
  active: boolean;
}

export const defaultRules: ModerationRule[] = [
  {
    id: '1',
    name: 'كلمات مسيئة',
    condition: 'contains',
    pattern: arabicBadWords.join('|'),
    action: 'delete',
    severity: 'high',
    active: true,
  },
  {
    id: '2',
    name: 'كلمات إنجليزية مسيئة',
    condition: 'contains',
    pattern: englishBadWords.join('|'),
    action: 'delete',
    severity: 'high',
    active: true,
  },
  {
    id: '3',
    name: 'سبام',
    condition: 'contains',
    pattern: spamKeywords.join('|'),
    action: 'flag',
    severity: 'medium',
    active: true,
  },
  {
    id: '4',
    name: 'رسالة طويلة جداً',
    condition: 'length',
    pattern: '5000',
    action: 'warn',
    severity: 'low',
    active: true,
  },
];

// User warning levels
export interface UserWarning {
  id: string;
  userId: string;
  reason: string;
  issuedBy: string;
  issuedAt: string;
  expiresAt: string;
  active: boolean;
}

// Ban durations
export const banDurations = {
  temporary: { hours: 24, label: '24 ساعة' },
  week: { hours: 168, label: 'أسبوع' },
  month: { hours: 720, label: 'شهر' },
  permanent: { hours: -1, label: 'دائم' },
};

// Calculate if user should be banned
export function calculateBanLevel(warningCount: number): 'none' | 'warn' | 'temp_ban' | 'perm_ban' {
  if (warningCount === 0) return 'none';
  if (warningCount < 3) return 'warn';
  if (warningCount < 5) return 'temp_ban';
  return 'perm_ban';
}

// Filter for URLs
export function containsUrl(text: string): boolean {
  const urlPattern = /(https?:\/\/[^\s]+)/gi;
  return urlPattern.test(text);
}

// Check for suspicious patterns
export function detectSuspiciousActivity(text: string): boolean {
  const patterns = [
    /(.)\1{5,}/, // repeated characters
    /[A-Z\s]{50,}/, // long caps
    /\d{10,}/, // long numbers (phone numbers)
    /@+\w/, // multiple @ symbols
    /.+@.+\..+/, // email pattern
  ];

  return patterns.some(pattern => pattern.test(text));
}

// Sanitize text input
export function sanitizeInput(text: string): string {
  return text
    .replace(/[<>]/g, '') // remove angle brackets
    .replace(/javascript:/gi, '') // remove javascript
    .replace(/on\w+=/gi, '') // remove event handlers
    .trim();
}

// Get user reputation impact based on actions
export function getReputationImpact(action: string): number {
  const impacts: Record<string, number> = {
    'positive_interaction': 5,
    'helpful_answer': 10,
    'upload_quality_content': 15,
    'report_valid': 8,
    'spam_report_invalid': -5,
    'inappropriate_content': -20,
    'spam_content': -15,
    'harassment': -30,
  };
  return impacts[action] || 0;
}