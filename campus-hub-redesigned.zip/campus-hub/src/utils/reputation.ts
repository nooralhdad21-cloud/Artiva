import { User } from '../types';

// User reputation and points system
export interface UserReputation {
  userId: string;
  points: number;
  level: number;
  badges: Badge[];
  achievements: Achievement[];
  stats: ReputationStats;
  history: ReputationEvent[];
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  earnedAt: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  progress: number;
  target: number;
  completed: boolean;
  completedAt?: string;
  reward: number;
}

export interface ReputationStats {
  totalContributions: number;
  helpfulAnswers: number;
  resourcesUploaded: number;
  ridesCompleted: number;
  communityPosts: number;
  reportsSubmitted: number;
  validReports: number;
}

export interface ReputationEvent {
  id: string;
  type: ReputationEventType;
  points: number;
  description: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export type ReputationEventType =
  | 'post_created'
  | 'post_liked'
  | 'post_shared'
  | 'comment_added'
  | 'resource_uploaded'
  | 'resource_downloaded'
  | 'ride_created'
  | 'ride_completed'
  | 'ride_rated'
  | 'report_submitted'
  | 'report_valid'
  | 'report_invalid'
  | 'badge_earned'
  | 'achievement_completed'
  | 'content_flagged'
  | 'warning_issued'
  | 'account_verified';

// Badge definitions
export const BADGES: Badge[] = [
  {
    id: 'newcomer',
    name: 'مبتدئ',
    description: 'سجل في المنصة',
    icon: '🌱',
    color: '#10B981',
    earnedAt: '',
    rarity: 'common',
  },
  {
    id: 'contributor',
    name: 'مساهم',
    description: 'رفع 10 ملازم',
    icon: '📚',
    color: '#3B82F6',
    earnedAt: '',
    rarity: 'common',
  },
  {
    id: 'helper',
    name: 'مُجيب',
    description: 'أجاب على 50 سؤال',
    icon: '💬',
    color: '#8B5CF6',
    earnedAt: '',
    rarity: 'rare',
  },
  {
    id: 'trusted_driver',
    name: 'سائق موثوق',
    description: '20 رحلة بتقييم 5 نجوم',
    icon: '🚗',
    color: '#F59E0B',
    earnedAt: '',
    rarity: 'rare',
  },
  {
    id: 'community_pillar',
    name: 'ركيزة المجتمع',
    description: '100 منشور مفيد',
    icon: '🏛️',
    color: '#EC4899',
    earnedAt: '',
    rarity: 'epic',
  },
  {
    id: 'scholar',
    name: 'عالم',
    description: 'رفع 50 ملزمة',
    icon: '🎓',
    color: '#6366F1',
    earnedAt: '',
    rarity: 'epic',
  },
  {
    id: 'guardian',
    name: 'حارس',
    description: '10 إبلاغات صحيحة',
    icon: '🛡️',
    color: '#EF4444',
    earnedAt: '',
    rarity: 'rare',
  },
  {
    id: 'legend',
    name: 'أسطورة',
    description: '1000 نقطة سمعة',
    icon: '⭐',
    color: '#FFD700',
    earnedAt: '',
    rarity: 'legendary',
  },
  {
    id: 'verified',
    name: 'موثق',
    description: 'تم توثيق الحساب',
    icon: '✓',
    color: '#10B981',
    earnedAt: '',
    rarity: 'common',
  },
];

// Achievement definitions
export const ACHIEVEMENTS: Omit<Achievement, 'progress' | 'completed' | 'completedAt'>[] = [
  {
    id: 'first_post',
    title: 'أول منشور',
    description: 'انشر أول منشور في المجتمع',
    icon: '✍️',
    target: 1,
    reward: 20,
  },
  {
    id: 'first_resource',
    title: 'أول ملزمة',
    description: 'ارفع أول ملزمة تعليمية',
    icon: '📤',
    target: 1,
    reward: 30,
  },
  {
    id: 'first_ride',
    title: 'أول خط',
    description: 'انشر أول خط نقل',
    icon: '🚌',
    target: 1,
    reward: 25,
  },
  {
    id: 'first_chat',
    title: 'أول محادثة',
    description: 'ابدأ أول محادثة',
    icon: '💬',
    target: 1,
    reward: 10,
  },
  {
    id: 'contributor_10',
    title: 'مساهم صغير',
    description: 'رفع 10 ملازم',
    icon: '📚',
    target: 10,
    reward: 100,
  },
  {
    id: 'contributor_50',
    title: 'مساهم كبير',
    description: 'رفع 50 ملزمة',
    icon: '📚',
    target: 50,
    reward: 250,
  },
  {
    id: 'helpful_10',
    title: 'مُجيب',
    description: 'أجب على 10 أسئلة',
    icon: '💬',
    target: 10,
    reward: 75,
  },
  {
    id: 'helpful_50',
    title: 'خبير',
    description: 'أجب على 50 سؤال',
    icon: '🧠',
    target: 50,
    reward: 200,
  },
  {
    id: 'driver_10',
    title: 'سائق متمرس',
    description: 'أتم 10 رحلات',
    icon: '🚗',
    target: 10,
    reward: 150,
  },
  {
    id: 'driver_50',
    title: 'سائق محترف',
    description: 'أتم 50 رحلة',
    icon: '🏆',
    target: 50,
    reward: 500,
  },
  {
    id: 'reporter_5',
    title: 'عين المجتمع',
    description: 'قدم 5 إبلاغات صحيحة',
    icon: '👁️',
    target: 5,
    reward: 50,
  },
  {
    id: 'reporter_20',
    title: 'حارس',
    description: 'قدم 20 إبلاغ صحيح',
    icon: '🛡️',
    target: 20,
    reward: 200,
  },
];

// Points configuration
export const POINTS_CONFIG = {
  post_created: 5,
  post_liked: 2,
  post_shared: 3,
  comment_added: 3,
  resource_uploaded: 10,
  resource_downloaded: 2,
  ride_created: 8,
  ride_completed: 10,
  ride_rated: 5,
  report_submitted: 5,
  report_valid: 15,
  report_invalid: -10,
  content_flagged: -20,
  warning_issued: -30,
  account_verified: 50,
};

// Level thresholds
export const LEVEL_THRESHOLDS = [
  { level: 1, minPoints: 0, title: 'مبتدئ', color: '#94A3B8' },
  { level: 2, minPoints: 100, title: 'متدرب', color: '#10B981' },
  { level: 3, minPoints: 300, title: 'نشط', color: '#3B82F6' },
  { level: 4, minPoints: 600, title: 'متميز', color: '#8B5CF6' },
  { level: 5, minPoints: 1000, title: 'خبير', color: '#F59E0B' },
  { level: 6, minPoints: 2000, title: 'نجم', color: '#EC4899' },
  { level: 7, minPoints: 5000, title: 'أسطورة', color: '#FFD700' },
];

// Calculate user level
export function calculateLevel(points: number): { level: number; title: string; color: string; progress: number; nextLevelPoints: number } {
  let currentLevel = LEVEL_THRESHOLDS[0];
  let nextLevel = LEVEL_THRESHOLDS[1];

  for (let i = 0; i < LEVEL_THRESHOLDS.length; i++) {
    if (points >= LEVEL_THRESHOLDS[i].minPoints) {
      currentLevel = LEVEL_THRESHOLDS[i];
      nextLevel = LEVEL_THRESHOLDS[i + 1] || LEVEL_THRESHOLDS[i];
    }
  }

  const currentLevelPoints = points - currentLevel.minPoints;
  const requiredPoints = (nextLevel?.minPoints || currentLevel.minPoints) - currentLevel.minPoints;
  const progress = requiredPoints > 0 ? (currentLevelPoints / requiredPoints) * 100 : 100;

  return {
    level: currentLevel.level,
    title: currentLevel.title,
    color: currentLevel.color,
    progress: Math.min(progress, 100),
    nextLevelPoints: nextLevel?.minPoints || currentLevel.minPoints,
  };
}

// Create initial reputation for a new user
export function createInitialReputation(userId: string): UserReputation {
  return {
    userId,
    points: 50, // Welcome bonus
    level: 1,
    badges: [BADGES.find(b => b.id === 'newcomer')!],
    achievements: ACHIEVEMENTS.map(a => ({
      ...a,
      progress: 0,
      completed: false,
    })),
    stats: {
      totalContributions: 0,
      helpfulAnswers: 0,
      resourcesUploaded: 0,
      ridesCompleted: 0,
      communityPosts: 0,
      reportsSubmitted: 0,
      validReports: 0,
    },
    history: [
      {
        id: '1',
        type: 'account_verified',
        points: 50,
        description: 'مرحباً بك في Campus Hub!',
        timestamp: new Date().toISOString(),
      },
    ],
  };
}

// Add points to user
export function addPoints(
  reputation: UserReputation,
  eventType: ReputationEventType,
  metadata?: Record<string, any>
): UserReputation {
  const pointsToAdd = POINTS_CONFIG[eventType] || 0;
  const newPoints = Math.max(0, reputation.points + pointsToAdd);
  const newLevel = calculateLevel(newPoints);

  const newEvent: ReputationEvent = {
    id: Date.now().toString(),
    type: eventType,
    points: pointsToAdd,
    description: getEventDescription(eventType, pointsToAdd),
    timestamp: new Date().toISOString(),
    metadata,
  };

  // Update stats based on event type
  const newStats = { ...reputation.stats };
  switch (eventType) {
    case 'resource_uploaded':
      newStats.resourcesUploaded++;
      break;
    case 'post_created':
      newStats.communityPosts++;
      break;
    case 'ride_completed':
      newStats.ridesCompleted++;
      break;
    case 'report_valid':
      newStats.validReports++;
      break;
    case 'report_submitted':
      newStats.reportsSubmitted++;
      break;
  }

  return {
    ...reputation,
    points: newPoints,
    level: newLevel.level,
    stats: newStats,
    history: [newEvent, ...reputation.history.slice(0, 49)], // Keep last 50 events
  };
}

// Get event description in Arabic
function getEventDescription(eventType: ReputationEventType, points: number): string {
  const descriptions: Record<ReputationEventType, string> = {
    post_created: `تم نشر منشور جديد (+${points})`,
    post_liked: `تم الإعجاب بمنشورك (+${points})`,
    post_shared: `تم مشاركة منشورك (+${points})`,
    comment_added: `تم إضافة تعليق (+${points})`,
    resource_uploaded: `تم رفع ملزمة جديدة (+${points})`,
    resource_downloaded: `تم تحميل ملزمة (+${points})`,
    ride_created: `تم نشر خط جديد (+${points})`,
    ride_completed: `تم إتمام رحلة (+${points})`,
    ride_rated: `تم تقييم رحلة (+${points})`,
    report_submitted: `تم تقديم إبلاغ (+${points})`,
    report_valid: `تم تأكيد صحة الإبلاغ (+${points})`,
    report_invalid: `تم رفض الإبلاغ (${points})`,
    badge_earned: `تم الحصول على شارة جديدة!`,
    achievement_completed: `تم إتمام إنجاز!`,
    content_flagged: `تم حذف محتوى مخالف (${points})`,
    warning_issued: `تم إصدار تحذير (${points})`,
    account_verified: `تم توثيق الحساب`,
  };

  return descriptions[eventType] || `حدث (${points})`;
}

// Check for new badges
export function checkBadges(reputation: UserReputation): Badge[] {
  const earnedBadges: Badge[] = [];

  // Check contributor badge
  if (reputation.stats.resourcesUploaded >= 10 && !reputation.badges.find(b => b.id === 'contributor')) {
    const badge = { ...BADGES.find(b => b.id === 'contributor')!, earnedAt: new Date().toISOString() };
    earnedBadges.push(badge);
  }

  // Check trusted driver badge
  if (reputation.stats.ridesCompleted >= 20 && !reputation.badges.find(b => b.id === 'trusted_driver')) {
    const badge = { ...BADGES.find(b => b.id === 'trusted_driver')!, earnedAt: new Date().toISOString() };
    earnedBadges.push(badge);
  }

  // Check guardian badge
  if (reputation.stats.validReports >= 10 && !reputation.badges.find(b => b.id === 'guardian')) {
    const badge = { ...BADGES.find(b => b.id === 'guardian')!, earnedAt: new Date().toISOString() };
    earnedBadges.push(badge);
  }

  // Check legend badge
  if (reputation.points >= 1000 && !reputation.badges.find(b => b.id === 'legend')) {
    const badge = { ...BADGES.find(b => b.id === 'legend')!, earnedAt: new Date().toISOString() };
    earnedBadges.push(badge);
  }

  return earnedBadges;
}