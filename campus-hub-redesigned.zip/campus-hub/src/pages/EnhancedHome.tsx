import React, { useState, useEffect } from 'react';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreHorizontal,
  Car,
  BookOpen,
  Users,
  Image,
  Send,
  TrendingUp,
  Bell,
  Star,
  Zap,
  Eye,
  MoreVertical,
  Flag,
  Report,
  Filter,
  Clock,
  Award,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { posts, rides, resources, users } from '../data/mockData';
import { useApp } from '../context/AppContext';
import { Post } from '../types';
import { moderateText, ReportType } from '../utils/moderation';
import { BADGES, calculateLevel, POINTS_CONFIG } from '../utils/reputation';

export default function EnhancedHome() {
  const { user } = useApp();
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set(['3']));
  const [savedPosts, setSavedPosts] = useState<Set<string>>(new Set(['1']));
  const [newPostContent, setNewPostContent] = useState('');
  const [postType, setPostType] = useState<'general' | 'question' | 'help'>('general');
  const [showReportModal, setShowReportModal] = useState<string | null>(null);
  const [moderationWarning, setModerationWarning] = useState<string | null>(null);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [liveIndicator, setLiveIndicator] = useState(true);

  // Simulate typing indicator
  useEffect(() => {
    const interval = setInterval(() => {
      const randomUsers = ['أحمد', 'زينب', 'علي'].filter(() => Math.random() > 0.7);
      setTypingUsers(randomUsers);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleContentChange = (content: string) => {
    setNewPostContent(content);

    // Real-time moderation check
    if (content.length > 10) {
      const result = moderateText(content);
      if (!result.isClean) {
        setModerationWarning(result.reason || 'محتوى غير مناسب');
      } else if (result.severity === 'low') {
        setModerationWarning(result.suggestions?.[0] || null);
      } else {
        setModerationWarning(null);
      }
    } else {
      setModerationWarning(null);
    }
  };

  const toggleLike = (postId: string) => {
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  const toggleSave = (postId: string) => {
    setSavedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 1) return 'الآن';
    if (hours < 24) return `منذ ${hours} ساعة`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `منذ ${days} يوم`;
    return date.toLocaleDateString('ar-IQ');
  };

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'question':
        return <span className="text-xl">❓</span>;
      case 'announcement':
        return <span className="text-xl">📢</span>;
      case 'image':
        return <Image size={16} className="text-secondary" />;
      default:
        return null;
    }
  };

  const getPostTypeColor = (type: string) => {
    switch (type) {
      case 'question':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'announcement':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getUserLevelInfo = () => {
    // Simulated user points - in real app, this would come from context
    const userPoints = 450;
    return calculateLevel(userPoints);
  };

  const levelInfo = getUserLevelInfo();

  return (
    <div className="max-w-4xl mx-auto">
      {/* Live Indicator */}
      <div className="flex items-center gap-2 mb-4">
        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-100 rounded-full">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
          <span className="text-sm text-green-700 font-medium">لايف</span>
        </div>
        {typingUsers.length > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-100 rounded-full">
            <span className="text-sm text-blue-700">
              {typingUsers.join(', ')} {typingUsers.length > 1 ? 'يكتبون' : 'يكتب'}
            </span>
            <span className="flex gap-0.5">
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></span>
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></span>
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></span>
            </span>
          </div>
        )}
      </div>

      {/* Welcome Section with User Level */}
      <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-6 mb-6 text-white">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center text-2xl font-bold">
              {user?.name.charAt(0)}
            </div>
            <div
              className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold border-2 border-white"
              style={{ backgroundColor: levelInfo.color }}
            >
              {levelInfo.level}
            </div>
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold">مرحباً {user?.name}! 👋</h2>
            <div className="flex items-center gap-3 text-sm text-white/80">
              <span className="flex items-center gap-1">
                <Star size={14} />
                {levelInfo.title}
              </span>
              <span>•</span>
              <span>{user?.university}</span>
            </div>
          </div>
          {/* Level Progress */}
          <div className="hidden sm:block text-center">
            <div className="text-2xl font-bold">{450}</div>
            <div className="text-xs text-white/70">نقطة</div>
          </div>
        </div>
        {/* Level Progress Bar */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-white/80 mb-1">
            <span>المستوى {levelInfo.level}</span>
            <span>{levelInfo.nextLevelPoints} نقطة للمستوى التالي</span>
          </div>
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-white rounded-full transition-all duration-500"
              style={{ width: `${levelInfo.progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <button className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all flex flex-col items-center gap-2 group">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-all">
            <Car className="text-primary group-hover:text-white" size={24} />
          </div>
          <span className="text-sm font-medium text-gray-700">خط جديد</span>
        </button>
        <button className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all flex flex-col items-center gap-2 group">
          <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center group-hover:bg-secondary group-hover:text-white transition-all">
            <BookOpen className="text-secondary group-hover:text-white" size={24} />
          </div>
          <span className="text-sm font-medium text-gray-700">رفع ملزمة</span>
        </button>
        <button className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all flex flex-col items-center gap-2 group">
          <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center group-hover:bg-accent group-hover:text-white transition-all">
            <Users className="text-accent group-hover:text-white" size={24} />
          </div>
          <span className="text-sm font-medium text-gray-700">سؤال</span>
        </button>
        <button className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all flex flex-col items-center gap-2 group">
          <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-all">
            <Zap className="text-purple-600 group-hover:text-white" size={24} />
          </div>
          <span className="text-sm font-medium text-gray-700">ترندات</span>
        </button>
      </div>

      {/* Create Post */}
      <div className="bg-white rounded-2xl shadow-sm p-4 mb-6">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
            {user?.name.charAt(0)}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <select
                value={postType}
                onChange={e => setPostType(e.target.value as any)}
                className="text-sm bg-gray-100 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/20"
              >
                <option value="general">منشور</option>
                <option value="question">سؤال</option>
                <option value="help">طلب مساعدة</option>
              </select>
            </div>
            <textarea
              value={newPostContent}
              onChange={e => handleContentChange(e.target.value)}
              placeholder={
                postType === 'question'
                  ? 'اكتب سؤالك هنا... اسأل زملاءك'
                  : postType === 'help'
                  ? 'اكتب طلبك هنا... الناس تحب تساعد'
                  : 'شنو تريد تشارك؟'
              }
              className="w-full h-24 bg-gray-50 rounded-xl p-4 resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
              dir="auto"
            />

            {/* Moderation Warning */}
            {moderationWarning && (
              <div className="flex items-center gap-2 mt-2 px-3 py-2 bg-yellow-50 rounded-lg text-yellow-700 text-sm">
                <AlertTriangle size={16} />
                <span>{moderationWarning}</span>
              </div>
            )}

            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center gap-2">
                <button className="p-2.5 hover:bg-gray-100 rounded-lg transition-colors">
                  <Image size={20} className="text-gray-500" />
                </button>
                <button className="p-2.5 hover:bg-gray-100 rounded-lg transition-colors">
                  <BookOpen size={20} className="text-gray-500" />
                </button>
                <button className="p-2.5 hover:bg-gray-100 rounded-lg transition-colors">
                  <Users size={20} className="text-gray-500" />
                </button>
              </div>
              <button
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all ${
                  moderationWarning && newPostContent.length > 10
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    : 'bg-primary text-white hover:bg-primary/90 shadow-lg shadow-primary/30'
                }`}
                disabled={!!moderationWarning && newPostContent.length > 10}
              >
                <Send size={18} />
                <span>نشر</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content Filters */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
        <button className="px-4 py-2 bg-primary text-white rounded-full font-medium text-sm whitespace-nowrap">
          الكل
        </button>
        <button className="px-4 py-2 bg-white text-gray-600 rounded-full font-medium text-sm whitespace-nowrap hover:bg-gray-100">
          ❓ أسئلة
        </button>
        <button className="px-4 py-2 bg-white text-gray-600 rounded-full font-medium text-sm whitespace-nowrap hover:bg-gray-100">
          📚 ملازم
        </button>
        <button className="px-4 py-2 bg-white text-gray-600 rounded-full font-medium text-sm whitespace-nowrap hover:bg-gray-100">
          🚗 خطوط
        </button>
        <button className="px-4 py-2 bg-white text-gray-600 rounded-full font-medium text-sm whitespace-nowrap hover:bg-gray-100">
          📢 إعلانات
        </button>
      </div>

      {/* Feed */}
      <div className="space-y-6">
        {posts.map(post => (
          <article key={post.id} className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-md transition-all">
            {/* Post Header */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
                    {post.author.name.charAt(0)}
                  </div>
                  {/* Online indicator */}
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-gray-800">{post.author.name}</h4>
                    {/* Verified badge */}
                    <span className="text-blue-500" title="موثق">✓</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <span>{post.author.department}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock size={12} />
                      {formatTime(post.createdAt)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {/* Post Type Badge */}
                <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getPostTypeColor(post.type)}`}>
                  {post.type === 'question' ? '❓ سؤال' : post.type === 'announcement' ? '📢 إعلان' : 'منشور'}
                </span>
                <div className="relative">
                  <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <MoreHorizontal size={20} className="text-gray-400" />
                  </button>
                </div>
              </div>
            </div>

            {/* Post Content */}
            <div className="px-4 pb-3">
              <p className="text-gray-800 leading-relaxed">{post.content}</p>
              {post.tags && post.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {post.tags.map(tag => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full hover:bg-primary/20 cursor-pointer transition-colors"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Post Image (if any) */}
            {post.type === 'image' && post.images && (
              <div className="px-4 pb-4">
                <div className="rounded-xl overflow-hidden bg-gray-100 aspect-video flex items-center justify-center">
                  <span className="text-gray-400">صورة المرفق</span>
                </div>
              </div>
            )}

            {/* Post Stats */}
            <div className="px-4 py-2 bg-gray-50 flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1 text-gray-500">
                  <Heart size={16} className="text-red-400 fill-red-400" />
                  <span className="font-medium">{post.likes}</span>
                </span>
                <span className="flex items-center gap-1 text-gray-500">
                  <MessageCircle size={16} />
                  <span className="font-medium">{post.comments.length}</span>
                </span>
                <span className="flex items-center gap-1 text-gray-500">
                  <Eye size={16} />
                  <span className="font-medium">234</span>
                </span>
              </div>
              <span className="text-gray-400 text-xs">
                ID: {post.id}
              </span>
            </div>

            {/* Post Actions */}
            <div className="px-4 py-3 border-t border-gray-100 flex items-center justify-between">
              <button
                onClick={() => toggleLike(post.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  likedPosts.has(post.id)
                    ? 'text-red-500 bg-red-50'
                    : 'text-gray-500 hover:bg-gray-100'
                }`}
              >
                <Heart size={20} className={likedPosts.has(post.id) ? 'fill-current' : ''} />
                <span className="text-sm font-medium">إعجاب</span>
              </button>
              <button className="flex items-center gap-2 px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-all">
                <MessageCircle size={20} />
                <span className="text-sm font-medium">تعليق</span>
              </button>
              <button className="flex items-center gap-2 px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-all">
                <Share2 size={20} />
                <span className="text-sm font-medium">مشاركة</span>
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleSave(post.id)}
                  className={`p-2 rounded-lg transition-all ${
                    savedPosts.has(post.id)
                      ? 'text-primary bg-primary/10'
                      : 'text-gray-400 hover:bg-gray-100'
                  }`}
                >
                  <Bookmark size={20} className={savedPosts.has(post.id) ? 'fill-current' : ''} />
                </button>
                <button
                  onClick={() => setShowReportModal(post.id)}
                  className="p-2 text-gray-400 hover:text-red-500 rounded-lg transition-all"
                  title="إبلاغ"
                >
                  <Flag size={20} />
                </button>
              </div>
            </div>

            {/* Comments Preview */}
            {post.comments.length > 0 && (
              <div className="px-4 pb-4">
                <div className="bg-gray-50 rounded-xl p-3 space-y-2">
                  {post.comments.slice(0, 2).map(comment => (
                    <div key={comment.id} className="flex items-start gap-2">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-xs font-bold">
                        {comment.author.name.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <span className="font-medium text-sm text-gray-800">{comment.author.name}</span>
                        <p className="text-sm text-gray-600">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                  {post.comments.length > 2 && (
                    <button className="text-sm text-primary font-medium hover:underline">
                      عرض جميع التعليقات ({post.comments.length})
                    </button>
                  )}
                </div>
              </div>
            )}
          </article>
        ))}
      </div>

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowReportModal(null)} />
          <div className="relative bg-white rounded-3xl w-full max-w-md p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Flag size={24} className="text-red-500" />
              إبلاغ عن محتوى
            </h3>
            <div className="space-y-3">
              <button className="w-full text-right p-4 rounded-xl border hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🚫</span>
                  <div>
                    <p className="font-medium text-gray-800">محتوى مسيء أو عنيف</p>
                    <p className="text-sm text-gray-500">يحتوي على ألفاظ مسيئة أو تهديد</p>
                  </div>
                </div>
              </button>
              <button className="w-full text-right p-4 rounded-xl border hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">📸</span>
                  <div>
                    <p className="font-medium text-gray-800">صور غير لائقة</p>
                    <p className="text-sm text-gray-500">يحتوي على صور مخالفة</p>
                  </div>
                </div>
              </button>
              <button className="w-full text-right p-4 rounded-xl border hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">📢</span>
                  <div>
                    <p className="font-medium text-gray-800">سبام أو إعلانات</p>
                    <p className="text-sm text-gray-500">محتوى تسويقي أو متكرر</p>
                  </div>
                </div>
              </button>
              <button className="w-full text-right p-4 rounded-xl border hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🎭</span>
                  <div>
                    <p className="font-medium text-gray-800">حساب مزيف</p>
                    <p className="text-sm text-gray-500">يمثل نفسه بشكل خاطئ</p>
                  </div>
                </div>
              </button>
            </div>
            <div className="flex items-center gap-3 mt-6">
              <button
                onClick={() => setShowReportModal(null)}
                className="flex-1 px-6 py-3 border border-gray-200 rounded-xl font-medium hover:bg-gray-50 transition-colors"
              >
                إلغاء
              </button>
              <button className="flex-1 px-6 py-3 bg-red-500 text-white rounded-xl font-medium hover:bg-red-600 transition-colors">
                إرسال الإبلاغ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Spacing for Mobile Nav */}
      <div className="h-20" />
    </div>
  );
}