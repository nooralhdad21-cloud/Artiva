import React from 'react';
import {
  Bell,
  Car,
  MessageCircle,
  BookOpen,
  Users,
  Settings,
  Check,
  CheckCheck,
  Trash2,
  Filter,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const notificationIcons = {
  ride: <Car size={20} className="text-primary" />,
  message: <MessageCircle size={20} className="text-secondary" />,
  resource: <BookOpen size={20} className="text-green-500" />,
  community: <Users size={20} className="text-purple-500" />,
  system: <Settings size={20} className="text-gray-500" />,
};

const notificationColors = {
  ride: 'bg-primary/10',
  message: 'bg-secondary/10',
  resource: 'bg-green-100',
  community: 'bg-purple-100',
  system: 'bg-gray-100',
};

export default function Notifications() {
  const { notifications, markAsRead, markAllAsRead, unreadCount } = useApp();

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 1) return 'الآن';
    if (hours < 24) return `منذ ${hours} ساعة`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `منذ ${days} يوم`;
    return date.toLocaleDateString('ar-IQ');
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">الإشعارات</h1>
          <p className="text-gray-500 text-sm">
            {unreadCount > 0 ? `لديك ${unreadCount} إشعار غير مقروء` : 'جميع الإشعارات مقروءة'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2.5 hover:bg-gray-100 rounded-xl transition-colors">
            <Filter size={20} className="text-gray-600" />
          </button>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="flex items-center gap-2 px-4 py-2 text-primary hover:bg-primary/10 rounded-xl transition-colors"
            >
              <CheckCheck size={20} />
              <span>قراءة الكل</span>
            </button>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        {notifications.length > 0 ? (
          notifications.map(notification => (
            <div
              key={notification.id}
              onClick={() => markAsRead(notification.id)}
              className={`
                p-5 border-b border-gray-100 last:border-0 cursor-pointer hover:bg-gray-50 transition-colors
                ${!notification.read ? 'bg-primary/5' : ''}
              `}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${notificationColors[notification.type]}`}>
                  {notificationIcons[notification.type]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className={`font-semibold ${!notification.read ? 'text-gray-800' : 'text-gray-700'}`}>
                        {notification.title}
                      </h4>
                      <p className="text-sm text-gray-500 mt-1">{notification.body}</p>
                    </div>
                    {!notification.read && (
                      <div className="w-3 h-3 bg-primary rounded-full flex-shrink-0 mt-1" />
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-2">
                    {formatTime(notification.createdAt)}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
              <Bell size={40} className="text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">لا توجد إشعارات</h3>
            <p className="text-gray-500">ستظهر الإشعارات هنا عندما يكون لديك جديد</p>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="mt-6 bg-white rounded-2xl shadow-sm p-5">
        <h3 className="font-bold text-gray-800 mb-4">إعدادات الإشعارات</h3>
        <div className="space-y-3">
          {[
            { label: 'إشعارات الخطوط', enabled: true },
            { label: 'إشعارات الرسائل', enabled: true },
            { label: 'إشعارات المصادر الجديدة', enabled: true },
            { label: 'إشعارات المجتمع', enabled: false },
            { label: 'إشعارات النظام', enabled: true },
          ].map((setting, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
              <span className="text-gray-700">{setting.label}</span>
              <button
                className={`
                  w-12 h-6 rounded-full transition-colors relative
                  ${setting.enabled ? 'bg-primary' : 'bg-gray-300'}
                `}
              >
                <div
                  className={`
                    absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all
                    ${setting.enabled ? 'right-7' : 'right-1'}
                  `}
                />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}