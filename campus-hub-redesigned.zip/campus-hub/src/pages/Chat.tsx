import React, { useState } from 'react';
import {
  Search,
  MessageCircle,
  Image,
  Paperclip,
  Send,
  MapPin,
  MoreVertical,
  Phone,
  Video,
  ArrowRight,
  Users,
} from 'lucide-react';
import { chats, mockMessages } from '../data/mockData';
import { useApp } from '../context/AppContext';
import { Chat as ChatType, Message } from '../types';

export default function Chat() {
  const { user } = useApp();
  const [selectedChat, setSelectedChat] = useState<ChatType | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredChats = chats.filter(chat => {
    if (!searchQuery) return true;
    const name = chat.type === 'group' ? chat.name : chat.participants.find(p => p.id !== user?.id)?.name;
    return name?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const getChatName = (chat: ChatType) => {
    if (chat.type === 'group') return chat.name;
    return chat.participants.find(p => p.id !== user?.id)?.name;
  };

  const getChatAvatar = (chat: ChatType) => {
    if (chat.type === 'group') return null;
    return chat.participants.find(p => p.id !== user?.id);
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 1) return 'الآن';
    if (hours < 24) return `${hours}:${String(Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))).padStart(2, '0')}`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}ي`;
    return date.toLocaleDateString('ar-IQ', { month: 'short', day: 'numeric' });
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedChat) return;
    // In a real app, this would send the message
    setMessageInput('');
  };

  const currentMessages = selectedChat ? mockMessages[selectedChat.id] || [] : [];

  return (
    <div className="h-[calc(100vh-140px)] flex bg-white rounded-2xl shadow-sm overflow-hidden">
      {/* Chat List */}
      <div className={`w-full md:w-80 border-l border-gray-100 flex flex-col ${selectedChat ? 'hidden md:flex' : 'flex'}`}>
        {/* Header */}
        <div className="p-4 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-800 mb-4">الدردشة</h2>
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="بحث..."
              className="w-full pr-10 pl-4 py-2.5 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto">
          {filteredChats.map(chat => (
            <div
              key={chat.id}
              onClick={() => setSelectedChat(chat)}
              className={`
                p-4 flex items-center gap-3 cursor-pointer hover:bg-gray-50 transition-colors
                ${selectedChat?.id === chat.id ? 'bg-primary/5' : ''}
              `}
            >
              {/* Avatar */}
              {chat.type === 'group' ? (
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-secondary to-teal-400 flex items-center justify-center">
                  <Users size={24} className="text-white" />
                </div>
              ) : (
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
                  {getChatName(chat)?.charAt(0)}
                </div>
              )}

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-gray-800 truncate">{getChatName(chat)}</h4>
                  {chat.lastMessage && (
                    <span className="text-xs text-gray-500">{formatTime(chat.lastMessage.createdAt)}</span>
                  )}
                </div>
                {chat.lastMessage && (
                  <p className="text-sm text-gray-500 truncate">{chat.lastMessage.content}</p>
                )}
              </div>

              {/* Unread Badge */}
              {chat.unreadCount > 0 && (
                <div className="w-6 h-6 bg-accent text-white text-xs rounded-full flex items-center justify-center font-medium">
                  {chat.unreadCount}
                </div>
              )}
            </div>
          ))}

          {filteredChats.length === 0 && (
            <div className="text-center py-12">
              <MessageCircle size={48} className="mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500">لا توجد محادثات</p>
            </div>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className={`flex-1 flex flex-col ${!selectedChat ? 'hidden md:flex' : 'flex'}`}>
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSelectedChat(null)}
                  className="md:hidden p-2 hover:bg-gray-100 rounded-full"
                >
                  <ArrowRight size={20} />
                </button>
                {selectedChat.type === 'group' ? (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-secondary to-teal-400 flex items-center justify-center">
                    <Users size={20} className="text-white" />
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
                    {getChatName(selectedChat)?.charAt(0)}
                  </div>
                )}
                <div>
                  <h3 className="font-semibold text-gray-800">{getChatName(selectedChat)}</h3>
                  <p className="text-xs text-gray-500">
                    {selectedChat.type === 'group' ? `${selectedChat.participants.length} members` : 'متصل الآن'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <Phone size={20} className="text-gray-600" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <Video size={20} className="text-gray-600" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <MoreVertical size={20} className="text-gray-600" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {currentMessages.map(message => {
                const isOwn = message.senderId === user?.id;
                return (
                  <div
                    key={message.id}
                    className={`flex ${isOwn ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`
                        max-w-[75%] px-4 py-3 rounded-2xl
                        ${isOwn
                          ? 'bg-primary text-white rounded-br-md'
                          : 'bg-gray-100 text-gray-800 rounded-bl-md'
                        }
                      `}
                    >
                      {!isOwn && (
                        <p className="text-xs font-medium mb-1 opacity-70">{message.sender.name}</p>
                      )}
                      <p className="text-sm">{message.content}</p>
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mt-2 flex items-center gap-2 bg-white/10 rounded-lg p-2">
                          <Paperclip size={16} />
                          <span className="text-xs">ملف مرفق</span>
                        </div>
                      )}
                      <p className={`text-xs mt-1 ${isOwn ? 'text-white/70' : 'text-gray-500'}`}>
                        {formatTime(message.createdAt)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-100">
              <div className="flex items-center gap-3">
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <Image size={22} className="text-gray-500" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <Paperclip size={22} className="text-gray-500" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <MapPin size={22} className="text-gray-500" />
                </button>
                <input
                  type="text"
                  value={messageInput}
                  onChange={e => setMessageInput(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && handleSendMessage()}
                  placeholder="اكتب رسالة..."
                  className="flex-1 px-4 py-2.5 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                />
                <button
                  onClick={handleSendMessage}
                  className="p-3 bg-primary text-white rounded-full hover:bg-primary/90 transition-colors"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                <MessageCircle size={48} className="text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">اختر محادثة</h3>
              <p className="text-gray-500">اختر محادثة من القائمة للبدء بالمحادثة</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}