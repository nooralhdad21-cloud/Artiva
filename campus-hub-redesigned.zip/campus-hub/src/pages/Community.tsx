import React, { useState } from 'react';
import {
  Users,
  MessageCircle,
  Heart,
  Share2,
  MoreHorizontal,
  Image,
  Send,
  TrendingUp,
  Filter,
  Bookmark,
  Award,
  Clock,
} from 'lucide-react';
import { posts, users } from '../data/mockData';
import { useApp } from '../context/AppContext';

const trendingTopics = [
  { tag: 'محاضرات', posts: 45 },
  { tag: 'ملازم', posts: 32 },
  { tag: 'خطوط', posts: 28 },
  { tag: 'امتحانات', posts: 21 },
  { tag: 'برمجة', posts: 18 },
];

const topContributors = users.slice(0, 3);

export default function Community() {
  const { user } = useApp();
  const [newPostContent, setNewPostContent] = useState('');
  const [postType, setPostType] = useState<'general' | 'question' | 'help'>('general');
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());

  const toggleLike = (postId: string) => {
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 1) return 'الآن';
    if (hours < 24) return `منذ ${hours} ساعة`;
    const days = Math.floor(hours / 24);
    return `منذ ${days} يوم`;
  };

  const getPostTypeBadge = (type: string) => {
    switch (type) {
      case 'question':
        return { text: 'سؤال', bg: 'bg-blue-100', textColor: 'text-blue-700' };
      case 'announcement':
        return { text: 'إعلان', bg: 'bg-purple-100', textColor: 'text-purple-700' };
      default:
        return { text: 'منشور', bg: 'bg-gray-100', textColor: 'text-gray-700' };
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">المجتمع الجامعي</h1>
            <p className="text-gray-500 text-sm">اسأل، شارك، وناقش مع زملائك</p>
          </div>

          {/* Create Post */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-lg">
                {user?.name.charAt(0)}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800">{user?.name}</h3>
                <select
                  value={postType}
                  onChange={e => setPostType(e.target.value as any)}
                  className="text-sm bg-transparent text-gray-500 focus:outline-none cursor-pointer"
                >
                  <option value="general">منشور عام</option>
                  <option value="question">سؤال</option>
                  <option value="help">طلب مساعدة</option>
                </select>
              </div>
            </div>
            <textarea
              value={newPostContent}
              onChange={e => setNewPostContent(e.target.value)}
              placeholder={postType === 'question' ? 'اكتب سؤالك هنا...' : postType === 'help' ? 'اكتب طلبك هنا...' : 'شنو تريد تشارك؟'}
              className="w-full h-24 bg-gray-50 rounded-xl p-4 resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
            />
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <button className="p-2.5 hover:bg-gray-100 rounded-lg transition-colors">
                  <Image size={22} className="text-gray-500" />
                </button>
              </div>
              <button className="flex items-center gap-2 px-5 py-2.5 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-all">
                <Send size={18} />
                <span>نشر</span>
              </button>
            </div>
          </div>

          {/* Posts */}
          <div className="space-y-4">
            {posts.map(post => {
              const badge = getPostTypeBadge(post.type);
              return (
                <article key={post.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                  <div className="p-5">
                    {/* Header */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
                          {post.author.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-gray-800">{post.author.name}</h4>
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${badge.bg} ${badge.textColor}`}>
                              {badge.text}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500">{post.author.department} • {formatTime(post.createdAt)}</p>
                        </div>
                      </div>
                      <button className="p-2 hover:bg-gray-100 rounded-full">
                        <MoreHorizontal size={20} className="text-gray-400" />
                      </button>
                    </div>

                    {/* Content */}
                    <p className="text-gray-800 leading-relaxed mb-4">{post.content}</p>

                    {/* Tags */}
                    {post.tags && (
                      <div className="flex flex-wrap gap-2 mb-4">
                        {post.tags.map(tag => (
                          <span key={tag} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <div className="flex items-center gap-4">
                        <button
                          onClick={() => toggleLike(post.id)}
                          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                            likedPosts.has(post.id)
                              ? 'text-red-500 bg-red-50'
                              : 'text-gray-500 hover:bg-gray-100'
                          }`}
                        >
                          <Heart size={20} className={likedPosts.has(post.id) ? 'fill-current' : ''} />
                          <span className="text-sm font-medium">{post.likes}</span>
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-all">
                          <MessageCircle size={20} />
                          <span className="text-sm font-medium">{post.comments.length}</span>
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-all">
                          <Share2 size={20} />
                        </button>
                      </div>
                      <button className="p-2 text-gray-400 hover:text-primary transition-colors">
                        <Bookmark size={20} />
                      </button>
                    </div>

                    {/* Comments Preview */}
                    {post.comments.length > 0 && (
                      <div className="mt-4 bg-gray-50 rounded-xl p-4 space-y-3">
                        {post.comments.slice(0, 2).map(comment => (
                          <div key={comment.id} className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-secondary to-teal-400 flex items-center justify-center text-white text-xs font-bold">
                              {comment.author.name.charAt(0)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-sm text-gray-800">{comment.author.name}</span>
                                <span className="text-xs text-gray-400">{formatTime(comment.createdAt)}</span>
                              </div>
                              <p className="text-sm text-gray-600">{comment.content}</p>
                            </div>
                          </div>
                        ))}
                        {post.comments.length > 2 && (
                          <button className="text-sm text-primary font-medium hover:underline">
                            عرض جميع التعليقات ({post.comments.length})
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Trending Topics */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp size={22} className="text-accent" />
              <h3 className="font-bold text-gray-800">الترندات</h3>
            </div>
            <div className="space-y-3">
              {trendingTopics.map((topic, index) => (
                <div key={topic.tag} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors cursor-pointer">
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                      {index + 1}
                    </span>
                    <span className="font-medium text-gray-700">#{topic.tag}</span>
                  </div>
                  <span className="text-sm text-gray-400">{topic.posts} منشور</span>
                </div>
              ))}
            </div>
          </div>

          {/* Top Contributors */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <div className="flex items-center gap-2 mb-4">
              <Award size={22} className="text-yellow-500" />
              <h3 className="font-bold text-gray-800">أفضل المساهمين</h3>
            </div>
            <div className="space-y-4">
              {topContributors.map((contributor, index) => (
                <div key={contributor.id} className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                    index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-400'
                  }`}>
                    {contributor.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-800">{contributor.name}</h4>
                    <p className="text-xs text-gray-500">{contributor.department}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-gradient-to-br from-primary to-secondary rounded-2xl p-5 text-white">
            <h3 className="font-bold mb-4">إحصائيات المجتمع</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold">1.2K</p>
                <p className="text-sm text-white/70">منشور</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">3.5K</p>
                <p className="text-sm text-white/70">عضو</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">856</p>
                <p className="text-sm text-white/70">سؤال</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">92%</p>
                <p className="text-sm text-white/70">متفاعل</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}