import React, { useState } from 'react';
import {
  Heart, MessageCircle, Share2, Bookmark, MoreHorizontal,
  Car, BookOpen, Users, Image, Send, TrendingUp,
  Flame, Bell, Star, Clock, ChevronLeft,
} from 'lucide-react';
import { posts, rides, resources } from '../data/mockData';
import { useApp } from '../context/AppContext';
import { Post } from '../types';

const quickActions = [
  { label: 'خط جديد',    icon: Car,       colorFrom: '#4F46E5', colorTo: '#6366F1', bg: '#EEF2FF', path: '/rides' },
  { label: 'رفع ملزمة',  icon: BookOpen,  colorFrom: '#059669', colorTo: '#10B981', bg: '#ECFDF5', path: '/resources' },
  { label: 'مجموعة',     icon: Users,     colorFrom: '#D97706', colorTo: '#F59E0B', bg: '#FFFBEB', path: '/community' },
  { label: 'دردشة',      icon: MessageCircle, colorFrom: '#0891B2', colorTo: '#06B6D4', bg: '#ECFEFF', path: '/chat' },
];

const statsData = [
  { label: 'طالب نشط', value: '1,240', icon: '🎓' },
  { label: 'خط متاح', value: '34',    icon: '🚌' },
  { label: 'ملزمة',    value: '520',   icon: '📚' },
];

export default function Home() {
  const { user } = useApp();
  const [likedPosts, setLikedPosts]   = useState<Set<string>>(new Set(['3']));
  const [savedPosts, setSavedPosts]   = useState<Set<string>>(new Set(['1']));
  const [newPostContent, setNewPostContent] = useState('');
  const [postType, setPostType] = useState<'text'|'question'>('text');

  const toggleLike = (id: string) => setLikedPosts(prev => {
    const s = new Set(prev);
    s.has(id) ? s.delete(id) : s.add(id);
    return s;
  });
  const toggleSave = (id: string) => setSavedPosts(prev => {
    const s = new Set(prev);
    s.has(id) ? s.delete(id) : s.add(id);
    return s;
  });

  const formatTime = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const h = Math.floor(diff / 3600000);
    if (h < 1) return 'الآن';
    if (h < 24) return `منذ ${h}س`;
    const d = Math.floor(h / 24);
    if (d < 7) return `منذ ${d}ي`;
    return new Date(dateStr).toLocaleDateString('ar-IQ');
  };

  const typeIcon = (type: string) => {
    if (type === 'question') return '❓';
    if (type === 'announcement') return '📢';
    return null;
  };

  return (
    <div className="max-w-5xl mx-auto space-y-5">

      {/* ─── Hero Card ─────────────────────────────── */}
      <div className="hero-card anim-fade-up">
        <div className="relative z-10">
          <div className="flex items-center gap-4">
            <div className="avatar w-14 h-14 text-xl flex-shrink-0" style={{ background: 'rgba(255,255,255,0.2)', border: '2px solid rgba(255,255,255,0.3)' }}>
              {user?.name.charAt(0)}
            </div>
            <div className="flex-1">
              <h2 className="text-white font-bold text-xl leading-tight">
                أهلاً {user?.name?.split(' ')[0]}! 👋
              </h2>
              <p className="text-sm mt-0.5" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {user?.university} • {user?.department} • مرحلة {user?.year}
              </p>
            </div>
          </div>

          {/* Stats chips */}
          <div className="flex gap-2 mt-5 flex-wrap">
            {statsData.map(s => (
              <div key={s.label} className="stat-chip">
                <span>{s.icon}</span>
                <span className="text-white font-bold">{s.value}</span>
                <span style={{ color: 'rgba(255,255,255,0.6)' }}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ─── Quick Actions ──────────────────────────── */}
      <div className="grid grid-cols-4 gap-3 anim-fade-up delay-1">
        {quickActions.map(a => {
          const Icon = a.icon;
          return (
            <a key={a.label} href={a.path} className="quick-action group">
              <div className="qa-icon" style={{ background: a.bg }}>
                <Icon size={22} style={{ color: a.colorFrom }} />
              </div>
              <span className="text-xs font-semibold text-center leading-tight" style={{ color: '#374151' }}>
                {a.label}
              </span>
            </a>
          );
        })}
      </div>

      {/* ─── Two Column Layout ──────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Feed */}
        <div className="lg:col-span-2 space-y-4">

          {/* New Post Box */}
          <div className="post-card anim-fade-up delay-2">
            <div className="flex gap-3 items-start">
              <div className="avatar w-10 h-10 text-base flex-shrink-0">{user?.name.charAt(0)}</div>
              <div className="flex-1">
                <textarea
                  value={newPostContent}
                  onChange={e => setNewPostContent(e.target.value)}
                  placeholder={postType === 'question' ? 'اكتب سؤالك هنا...' : 'شاركنا شيء مفيد...'}
                  rows={3}
                  className="w-full resize-none text-sm outline-none font-medium placeholder:font-normal"
                  style={{
                    background: '#F8FAFC', borderRadius: 12, padding: '12px 14px',
                    border: '1.5px solid #E2E8F0', fontFamily: 'Cairo, sans-serif',
                    color: '#1E293B', lineHeight: 1.7, transition: 'border-color 0.2s',
                  }}
                  onFocus={e => (e.target.style.borderColor = 'rgba(79,70,229,0.4)')}
                  onBlur={e  => (e.target.style.borderColor = '#E2E8F0')}
                />
              </div>
            </div>

            <div className="flex items-center justify-between mt-3 pt-3" style={{ borderTop: '1px solid #F1F5F9' }}>
              <div className="flex gap-2">
                {(['text','question'] as const).map(t => (
                  <button key={t} onClick={() => setPostType(t)}
                    className="btn btn-sm"
                    style={{
                      background: postType === t ? 'rgba(79,70,229,0.1)' : '#F1F5F9',
                      color: postType === t ? '#4F46E5' : '#64748B',
                      fontWeight: postType === t ? 700 : 500,
                    }}>
                    {t === 'text' ? '📝 منشور' : '❓ سؤال'}
                  </button>
                ))}
                <button className="btn btn-sm" style={{ background: '#F1F5F9', color: '#64748B' }}>
                  <Image size={15} /> صورة
                </button>
              </div>
              <button className="btn btn-primary btn-sm" disabled={!newPostContent.trim()}>
                <Send size={14} /> نشر
              </button>
            </div>
          </div>

          {/* Posts */}
          {posts.slice(0, 5).map((post, idx) => {
            const liked = likedPosts.has(post.id);
            const saved = savedPosts.has(post.id);
            const icon  = typeIcon(post.type);
            return (
              <div key={post.id} className={`post-card anim-fade-up delay-${Math.min(idx+3,5)}`}>
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="avatar w-10 h-10 text-sm">{post.author.name.charAt(0)}</div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm" style={{ color: '#1E293B' }}>{post.author.name}</span>
                        {icon && <span className="text-base">{icon}</span>}
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="text-xs" style={{ color: '#94A3B8' }}>{post.author.department}</span>
                        <span style={{ color: '#CBD5E1' }}>•</span>
                        <Clock size={11} style={{ color: '#CBD5E1' }} />
                        <span className="text-xs" style={{ color: '#94A3B8' }}>{formatTime(post.createdAt)}</span>
                      </div>
                    </div>
                  </div>
                  <button className="p-1.5 rounded-lg transition-colors btn-ghost">
                    <MoreHorizontal size={17} style={{ color: '#94A3B8' }} />
                  </button>
                </div>

                {/* Content */}
                <p className="text-sm leading-relaxed line-clamp-3 mb-3" style={{ color: '#374151' }}>{post.content}</p>

                {/* Tags */}
                {post.tags && post.tags.length > 0 && (
                  <div className="flex gap-2 flex-wrap mb-3">
                    {post.tags.map(tag => (
                      <span key={tag} className="text-xs px-2.5 py-1 rounded-full font-medium"
                        style={{ background: '#EEF2FF', color: '#4F46E5' }}>
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center gap-1 pt-2" style={{ borderTop: '1px solid #F8FAFC' }}>
                  <button onClick={() => toggleLike(post.id)}
                    className={`post-action-btn ${liked ? 'liked' : ''}`}>
                    <Heart size={16} fill={liked ? '#EF4444' : 'none'} />
                    {post.likes + (liked ? 1 : 0)}
                  </button>
                  <button className="post-action-btn">
                    <MessageCircle size={16} />
                    {post.comments.length}
                  </button>
                  <button className="post-action-btn">
                    <Share2 size={16} />
                    مشاركة
                  </button>
                  <button onClick={() => toggleSave(post.id)}
                    className={`post-action-btn mr-auto ${saved ? 'saved' : ''}`}>
                    <Bookmark size={16} fill={saved ? '#4F46E5' : 'none'} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-4 anim-fade-up delay-3">

          {/* Trending */}
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Flame size={18} style={{ color: '#F59E0B' }} />
              <h3 className="font-bold text-sm" style={{ color: '#1E293B' }}>الأكثر تداولاً</h3>
            </div>
            <div className="space-y-3">
              {['برمجة بايثون', 'امتحانات الفصل', 'مواعيد التسجيل', 'مشاريع التخرج', 'منح دراسية'].map((t, i) => (
                <div key={t} className="flex items-center gap-3 cursor-pointer group">
                  <span className="text-xs font-bold w-5 text-center" style={{ color: '#CBD5E1' }}>0{i+1}</span>
                  <div className="flex-1">
                    <p className="text-sm font-semibold group-hover:text-indigo-600 transition-colors" style={{ color: '#374151' }}>{t}</p>
                    <p className="text-xs" style={{ color: '#94A3B8' }}>{(120 - i*18).toLocaleString()} نشاط</p>
                  </div>
                  <TrendingUp size={14} style={{ color: '#34D399', opacity: 0.8 }} />
                </div>
              ))}
            </div>
          </div>

          {/* Latest Rides */}
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Car size={18} style={{ color: '#4F46E5' }} />
                <h3 className="font-bold text-sm" style={{ color: '#1E293B' }}>خطوط متاحة</h3>
              </div>
              <a href="/rides" className="text-xs font-semibold" style={{ color: '#4F46E5' }}>الكل</a>
            </div>
            <div className="space-y-3">
              {rides.slice(0, 3).map(ride => (
                <div key={ride.id} className="flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-colors"
                  style={{ background: '#F8FAFC' }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#EEF2FF')}
                  onMouseLeave={e => (e.currentTarget.style.background = '#F8FAFC')}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: '#EEF2FF' }}>
                    <Car size={16} style={{ color: '#4F46E5' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold truncate" style={{ color: '#1E293B' }}>{ride.from} → {ride.to}</p>
                    <p className="text-xs" style={{ color: '#94A3B8' }}>{ride.time} • {ride.availableSeats} مقعد</p>
                  </div>
                  <span className="text-xs font-bold px-2 py-1 rounded-lg flex-shrink-0" style={{ background: '#ECFDF5', color: '#059669' }}>
                    {ride.price.toLocaleString()}د
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Top Resources */}
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Star size={18} style={{ color: '#F59E0B' }} />
                <h3 className="font-bold text-sm" style={{ color: '#1E293B' }}>أحدث الملازم</h3>
              </div>
              <a href="/resources" className="text-xs font-semibold" style={{ color: '#4F46E5' }}>الكل</a>
            </div>
            <div className="space-y-3">
              {resources.slice(0, 3).map(r => (
                <div key={r.id} className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: '#FFFBEB' }}>
                    <BookOpen size={16} style={{ color: '#D97706' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold truncate" style={{ color: '#1E293B' }}>{r.title}</p>
                    <p className="text-xs" style={{ color: '#94A3B8' }}>{r.courseName} • {r.downloads} تحميل</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
