import React, { useState } from 'react';
import {
  Plus,
  MapPin,
  Clock,
  Users,
  Car,
  Search,
  Filter,
  ChevronLeft,
  MessageCircle,
  Star,
  Calendar,
} from 'lucide-react';
import { rides } from '../data/mockData';
import { useApp } from '../context/AppContext';
import { Ride } from '../types';

export default function Rides() {
  const { user } = useApp();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedRide, setSelectedRide] = useState<Ride | null>(null);
  const [filter, setFilter] = useState('all');

  const filteredRides = rides.filter(ride => {
    if (filter === 'all') return true;
    if (filter === 'available') return ride.availableSeats > 0;
    if (filter === 'mine') return ride.driverId === user?.id;
    return true;
  });

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'م' : 'ص';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('ar-IQ', { weekday: 'long', month: 'long', day: 'numeric' });
  };

  const getGenderLabel = (restriction: string) => {
    switch (restriction) {
      case 'male':
        return 'شباب فقط';
      case 'female':
        return 'بنات فقط';
      default:
        return 'الجميع';
    }
  };

  const getGenderColor = (restriction: string) => {
    switch (restriction) {
      case 'male':
        return 'bg-blue-100 text-blue-700';
      case 'female':
        return 'bg-pink-100 text-pink-700';
      default:
        return 'bg-green-100 text-green-700';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">الخطوط</h1>
          <p className="text-gray-500 text-sm">ابحث عن خط مناسب أو نشر خط جديد</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-5 py-2.5 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-all shadow-lg shadow-primary/30"
        >
          <Plus size={20} />
          <span>نشر خط</span>
        </button>
      </div>

      {/* Search and Filter */}
      <div className="flex items-center gap-3 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="ابحث عن خط..."
            className="w-full pr-10 pl-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
        </div>
        <select
          value={filter}
          onChange={e => setFilter(e.target.value)}
          className="px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
        >
          <option value="all">الكل</option>
          <option value="available">متوفر</option>
          <option value="mine">خطودي</option>
        </select>
      </div>

      {/* Ride Cards */}
      <div className="space-y-4">
        {filteredRides.map(ride => (
          <div
            key={ride.id}
            className="bg-white rounded-2xl shadow-sm p-5 hover:shadow-md transition-all cursor-pointer"
            onClick={() => setSelectedRide(ride)}
          >
            {/* Driver Info */}
            <div className="flex items-center gap-4 mb-4">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-xl">
                {ride.driver.name.charAt(0)}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800">{ride.driver.name}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Star size={14} className="text-yellow-500 fill-yellow-500" />
                  <span>4.8</span>
                  <span>•</span>
                  <span>{ride.driver.area}</span>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${getGenderColor(ride.genderRestriction)}`}>
                {getGenderLabel(ride.genderRestriction)}
              </div>
            </div>

            {/* Route */}
            <div className="flex items-center gap-4 mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <MapPin size={16} className="text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">من</p>
                    <p className="font-medium text-gray-800">{ride.from}</p>
                  </div>
                </div>
              </div>
              <div className="px-4">
                <div className="flex items-center gap-1 text-gray-400">
                  <div className="w-8 h-0.5 bg-gray-200" />
                  <Car size={20} />
                  <div className="w-8 h-0.5 bg-gray-200" />
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-secondary/10 flex items-center justify-center">
                    <MapPin size={16} className="text-secondary" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">إلى</p>
                    <p className="font-medium text-gray-800">{ride.to}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Details */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5 text-gray-600">
                  <Clock size={18} className="text-primary" />
                  <span className="font-medium">{formatTime(ride.time)}</span>
                </div>
                <div className="flex items-center gap-1.5 text-gray-600">
                  <Calendar size={18} className="text-secondary" />
                  <span className="text-sm">{formatDate(ride.date)}</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <Users size={18} className="text-gray-400" />
                  <span className="text-sm text-gray-600">
                    {ride.availableSeats}/{ride.seats} مقاعد
                  </span>
                </div>
                <div className="text-xl font-bold text-primary">
                  {ride.price.toLocaleString()} د.ع
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredRides.length === 0 && (
        <div className="text-center py-12">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
            <Car size={40} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">لا توجد خطوط</h3>
          <p className="text-gray-500 mb-4">ابحث عن خط مناسب أو نشر خط جديد</p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-6 py-2.5 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-all"
          >
            نشر خط جديد
          </button>
        </div>
      )}

      {/* Create Ride Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowCreateModal(false)} />
          <div className="relative bg-white rounded-3xl w-full max-w-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-6">نشر خط جديد</h2>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">منطقة الانطلاق</label>
                <input
                  type="text"
                  placeholder="مثال: المنصور"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الوجهة</label>
                <input
                  type="text"
                  placeholder="مثال: كلية الرافدين"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">التوقيت</label>
                  <input
                    type="time"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">المقاعد</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    placeholder="3"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">السعر (د.ع)</label>
                <input
                  type="number"
                  placeholder="2500"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الجنس المسموح</label>
                <div className="grid grid-cols-3 gap-3">
                  <button type="button" className="px-4 py-3 border border-gray-200 rounded-xl hover:border-primary">
                    الكل
                  </button>
                  <button type="button" className="px-4 py-3 border border-primary bg-primary/5 text-primary rounded-xl">
                    شباب فقط
                  </button>
                  <button type="button" className="px-4 py-3 border border-gray-200 rounded-xl hover:border-primary">
                    بنات فقط
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 px-6 py-3 border border-gray-200 rounded-xl font-medium hover:bg-gray-50 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-all"
                >
                  نشر الخط
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Ride Details Modal */}
      {selectedRide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSelectedRide(null)} />
          <div className="relative bg-white rounded-3xl w-full max-w-lg p-6">
            <button
              onClick={() => setSelectedRide(null)}
              className="absolute left-4 top-4 p-2 hover:bg-gray-100 rounded-full"
            >
              <ChevronLeft size={20} />
            </button>

            <div className="text-center mb-6">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold">
                {selectedRide.driver.name.charAt(0)}
              </div>
              <h2 className="text-xl font-bold text-gray-800">{selectedRide.driver.name}</h2>
              <div className="flex items-center justify-center gap-2 text-gray-500 mt-1">
                <Star size={16} className="text-yellow-500 fill-yellow-500" />
                <span>4.8</span>
                <span>•</span>
                <span>{selectedRide.driver.area}</span>
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl p-4 mb-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="flex-1 text-center">
                  <p className="text-sm text-gray-500">من</p>
                  <p className="font-semibold text-gray-800">{selectedRide.from}</p>
                </div>
                <Car size={24} className="text-gray-400" />
                <div className="flex-1 text-center">
                  <p className="text-sm text-gray-500">إلى</p>
                  <p className="font-semibold text-gray-800">{selectedRide.to}</p>
                </div>
              </div>
              <div className="flex items-center justify-around text-center">
                <div>
                  <Clock size={20} className="mx-auto mb-1 text-primary" />
                  <p className="text-sm font-medium">{formatTime(selectedRide.time)}</p>
                </div>
                <div>
                  <Calendar size={20} className="mx-auto mb-1 text-secondary" />
                  <p className="text-sm font-medium">{formatDate(selectedRide.date)}</p>
                </div>
                <div>
                  <Users size={20} className="mx-auto mb-1 text-gray-400" />
                  <p className="text-sm font-medium">{selectedRide.availableSeats} / {selectedRide.seats}</p>
                </div>
              </div>
            </div>

            <div className="text-center mb-6">
              <p className="text-gray-500 text-sm mb-1">سعر المقعد</p>
              <p className="text-3xl font-bold text-primary">
                {selectedRide.price.toLocaleString()} د.ع
              </p>
            </div>

            <button className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-primary to-secondary text-white rounded-xl font-medium hover:shadow-lg transition-all">
              <MessageCircle size={20} />
              <span>تواصل مع السائق</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}