import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  GraduationCap,
  MapPin,
  Phone,
  ChevronRight,
  ChevronLeft,
  Check,
  ArrowRight,
} from 'lucide-react';
import { universities, areas } from '../data/mockData';
import { useApp } from '../context/AppContext';

interface FormData {
  name: string;
  gender: string;
  universityId: string;
  collegeId: string;
  departmentId: string;
  year: string;
  area: string;
  phone: string;
}

const steps = [
  { id: 1, title: 'المعلومات الشخصية', icon: User },
  { id: 2, title: 'المعلومات الجامعية', icon: GraduationCap },
  { id: 3, title: 'الموقع والاتصال', icon: MapPin },
  { id: 4, title: ' تأكيد الحساب', icon: Check },
];

export default function Registration() {
  const navigate = useNavigate();
  const { setUser } = useApp();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    gender: '',
    universityId: '',
    collegeId: '',
    departmentId: '',
    year: '',
    area: '',
    phone: '',
  });

  const selectedUniversity = universities.find(u => u.id === formData.universityId);
  const selectedCollege = selectedUniversity?.colleges.find(c => c.id === formData.collegeId);

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
      ...(field === 'universityId' ? { collegeId: '', departmentId: '' } : {}),
      ...(field === 'collegeId' ? { departmentId: '' } : {}),
    }));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.name.trim() !== '' && formData.gender !== '';
      case 2:
        return formData.universityId !== '' && formData.collegeId !== '' && formData.departmentId !== '' && formData.year !== '';
      case 3:
        return formData.area !== '' && formData.phone.trim() !== '';
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (canProceed() && currentStep < 4) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    const university = universities.find(u => u.id === formData.universityId);
    const college = university?.colleges.find(c => c.id === formData.collegeId);
    const department = college?.departments.find(d => d.id === formData.departmentId);

    const newUser = {
      id: '1',
      name: formData.name,
      gender: formData.gender as 'male' | 'female',
      university: university?.name || '',
      universityId: formData.universityId,
      college: college?.name || '',
      collegeId: formData.collegeId,
      department: department?.name || '',
      departmentId: formData.departmentId,
      year: formData.year,
      area: formData.area,
      phone: formData.phone,
      role: 'student' as const,
      createdAt: new Date().toISOString(),
    };

    setUser(newUser);
    navigate('/home');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-2">
            <div className="w-14 h-14 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-2xl">C</span>
            </div>
            <span className="font-bold text-3xl text-gray-800">Campus Hub</span>
          </div>
          <p className="text-gray-500">منصتك الجامعية الأولى</p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-8">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isActive = currentStep === step.id;
            const isCompleted = currentStep > step.id;
            return (
              <React.Fragment key={step.id}>
                <div className="flex items-center">
                  <div
                    className={`
                      w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300
                      ${isActive || isCompleted
                        ? 'bg-primary text-white shadow-lg shadow-primary/30'
                        : 'bg-gray-200 text-gray-400'
                      }
                    `}
                  >
                    {isCompleted ? <Check size={24} /> : <Icon size={24} />}
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`
                      w-16 sm:w-24 h-1 mx-2 rounded-full transition-all duration-300
                      ${isCompleted ? 'bg-primary' : 'bg-gray-200'}
                    `}
                  />
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-3xl shadow-xl p-6 sm:p-8">
          {/* Step Title */}
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            {steps[currentStep - 1].title}
          </h2>

          {/* Step 1: Personal Info */}
          {currentStep === 1 && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الاسم الكامل</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => handleInputChange('name', e.target.value)}
                  placeholder="أدخل اسمك الكامل"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الجنس</label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => handleInputChange('gender', 'male')}
                    className={`
                      p-4 rounded-xl border-2 transition-all
                      ${formData.gender === 'male'
                        ? 'border-primary bg-primary/5 text-primary'
                        : 'border-gray-200 hover:border-gray-300'
                      }
                    `}
                  >
                    <span className="text-3xl mb-2 block">👨</span>
                    <span className="font-medium">ذكر</span>
                  </button>
                  <button
                    onClick={() => handleInputChange('gender', 'female')}
                    className={`
                      p-4 rounded-xl border-2 transition-all
                      ${formData.gender === 'female'
                        ? 'border-primary bg-primary/5 text-primary'
                        : 'border-gray-200 hover:border-gray-300'
                      }
                    `}
                  >
                    <span className="text-3xl mb-2 block">👩</span>
                    <span className="font-medium">أنثى</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: University Info */}
          {currentStep === 2 && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الجامعة</label>
                <select
                  value={formData.universityId}
                  onChange={e => handleInputChange('universityId', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white"
                >
                  <option value="">اختر الجامعة</option>
                  {universities.map(uni => (
                    <option key={uni.id} value={uni.id}>
                      {uni.name} - {uni.city}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الكلية</label>
                <select
                  value={formData.collegeId}
                  onChange={e => handleInputChange('collegeId', e.target.value)}
                  disabled={!selectedUniversity}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  <option value="">اختر الكلية</option>
                  {selectedUniversity?.colleges.map(col => (
                    <option key={col.id} value={col.id}>
                      {col.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">القسم</label>
                <select
                  value={formData.departmentId}
                  onChange={e => handleInputChange('departmentId', e.target.value)}
                  disabled={!selectedCollege}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  <option value="">اختر القسم</option>
                  {selectedCollege?.departments.map(dep => (
                    <option key={dep.id} value={dep.id}>
                      {dep.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">المرحلة</label>
                <select
                  value={formData.year}
                  onChange={e => handleInputChange('year', e.target.value)}
                  disabled={!selectedCollege}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  <option value="">اختر المرحلة</option>
                  {selectedCollege?.departments.find(d => d.id === formData.departmentId)?.years.map((year, i) => (
                    <option key={i} value={year}>
                      {year}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Step 3: Location & Contact */}
          {currentStep === 3 && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">المنطقة السكنية</label>
                <select
                  value={formData.area}
                  onChange={e => handleInputChange('area', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white"
                >
                  <option value="">اختر منطقتك</option>
                  {areas.map(area => (
                    <option key={area} value={area}>
                      {area}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
                <div className="relative">
                  <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => handleInputChange('phone', e.target.value)}
                    placeholder="07XXXXXXXX"
                    className="w-full pr-12 pl-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    dir="ltr"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Confirmation */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="bg-gray-50 rounded-2xl p-6">
                <h3 className="font-bold text-lg text-gray-800 mb-4">ملخص حسابك</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">الاسم:</span>
                    <span className="font-medium text-gray-800">{formData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">الجنس:</span>
                    <span className="font-medium text-gray-800">{formData.gender === 'male' ? 'ذكر' : 'أنثى'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">الجامعة:</span>
                    <span className="font-medium text-gray-800">{selectedUniversity?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">الكلية:</span>
                    <span className="font-medium text-gray-800">{selectedCollege?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">القسم:</span>
                    <span className="font-medium text-gray-800">
                      {selectedCollege?.departments.find(d => d.id === formData.departmentId)?.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">المرحلة:</span>
                    <span className="font-medium text-gray-800">{formData.year}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">المنطقة:</span>
                    <span className="font-medium text-gray-800">{formData.area}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">الهاتف:</span>
                    <span className="font-medium text-gray-800" dir="ltr">{formData.phone}</span>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-500 text-center">
                بالضغط على "إنشاء الحساب" فأنت توافق على شروط الاستخدام الخصوصية
              </p>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8">
            {currentStep > 1 ? (
              <button
                onClick={handleBack}
                className="flex items-center gap-2 px-6 py-3 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ChevronRight size={20} />
                <span>السابق</span>
              </button>
            ) : (
              <div />
            )}
            {currentStep < 4 ? (
              <button
                onClick={handleNext}
                disabled={!canProceed()}
                className={`
                  flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all
                  ${canProceed()
                    ? 'bg-primary text-white hover:bg-primary/90 shadow-lg shadow-primary/30'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  }
                `}
              >
                <span>التالي</span>
                <ChevronLeft size={20} />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-primary to-secondary text-white rounded-xl font-medium hover:shadow-lg transition-all"
              >
                <span>إنشاء الحساب</span>
                <ArrowRight size={20} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}