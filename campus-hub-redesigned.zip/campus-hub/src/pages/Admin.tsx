import React, { useState } from 'react';
import {
  Users,
  Car,
  BookOpen,
  Flag,
  TrendingUp,
  Shield,
  BarChart3,
  Settings,
  Search,
  MoreVertical,
  Ban,
  CheckCircle,
  AlertTriangle,
  Eye,
  MessageSquare,
  FileText,
  Activity,
  Clock,
  UserPlus,
  Route,
} from 'lucide-react';
import { users, posts, rides } from '../data/mockData';

const stats = [
  { label: 'إجمالي المستخدمين', value: '3,542', change: '+12%', icon: Users, color: 'primary' },
  { label: 'الرحلات النشطة', value: '128', change: '+8%', icon: Car, color: 'secondary' },
  { label: 'المصادر التعليمية', value: '856', change: '+15%', icon: BookOpen, color: 'green' },
  { label: 'الإبلاغات الجديدة', value: '23', change: '-5%', icon: Flag, color: 'orange' },
];

const recentActivity = [
  { type: 'user', action: 'تم توثيق طالب جديد', time: 'منذ 5 دقائق', icon: UserPlus },
  { type: 'ride', action: 'تم نشر خط جديد من المنصور', time: 'منذ 12 دقيقة', icon: Route },
  { type: 'report', action: 'تم حذف منشور مخالف', time: 'منذ 20 دقيقة', icon: Flag },
  { type: 'resource', action: 'تم رفع ملزمة جديدة', time: 'منذ 45 دقيقة', icon: FileText },
];

export default function Admin() {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');

  const tabs = [
    { id: 'overview', label: 'نظرة عامة', icon: BarChart3 },
    { id: 'users', label: 'المستخدمين', icon: Users },
    { id: 'rides', label: 'الخطوط', icon: Route },
    { id: 'content', label: 'المحتوى', icon: FileText },
    { id: 'reports', label: 'التقارير', icon: Flag },
  ];

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">لوحة التحكم</h1>
          <p className="text-gray-500 text-sm">إدارة المنصة والمستخدمين</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-xl">
          <Shield size={18} />
          <span className="font-medium">Admin Mode</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-all whitespace-nowrap
                ${activeTab === tab.id
                  ? 'bg-primary text-white shadow-lg shadow-primary/30'
                  : 'bg-white text-gray-600 hover:bg-gray-50 shadow-sm'
                }
              `}
            >
              <Icon size={20} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-2xl shadow-sm p-5">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-${stat.color}/10`}>
                  <Icon size={24} className={`text-${stat.color}`} />
                </div>
                <span className={`text-sm font-medium ${stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Users Table */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-800">إدارة المستخدمين</h3>
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="بحث..."
                  className="pr-8 pl-4 py-2 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm"
                />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-right text-sm text-gray-500 border-b border-gray-100">
                    <th className="pb-3 font-medium">المستخدم</th>
                    <th className="pb-3 font-medium">الجامعة</th>
                    <th className="pb-3 font-medium">الحالة</th>
                    <th className="pb-3 font-medium">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(user => (
                    <tr key={user.id} className="border-b border-gray-50 last:border-0">
                      <td className="py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{user.name}</p>
                            <p className="text-xs text-gray-500">{user.phone}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4">
                        <p className="text-sm text-gray-600">{user.university}</p>
                        <p className="text-xs text-gray-400">{user.department}</p>
                      </td>
                      <td className="py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          user.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                          user.role === 'driver' ? 'bg-blue-100 text-blue-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {user.role === 'admin' ? 'أدمن' : user.role === 'driver' ? 'سائق' : 'طالب'}
                        </span>
                      </td>
                      <td className="py-4">
                        <div className="flex items-center gap-2">
                          <button className="p-2 hover:bg-gray-100 rounded-lg">
                            <Eye size={18} className="text-gray-500" />
                          </button>
                          <button className="p-2 hover:bg-gray-100 rounded-lg">
                            <Ban size={18} className="text-red-500" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Recent Posts */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h3 className="font-bold text-gray-800 mb-4">المنشورات الأخيرة</h3>
            <div className="space-y-4">
              {posts.slice(0, 3).map(post => (
                <div key={post.id} className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
                    {post.author.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-gray-800">{post.author.name}</h4>
                      <span className="text-xs text-gray-400">منذ ساعة</span>
                    </div>
                    <p className="text-sm text-gray-600 line-clamp-2 mt-1">{post.content}</p>
                  </div>
                  <button className="p-2 hover:bg-gray-200 rounded-lg">
                    <MoreVertical size={18} className="text-gray-400" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Recent Activity */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Activity size={20} className="text-primary" />
              النشاط الأخير
            </h3>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => {
                const Icon = activity.icon;
                return (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon size={18} className="text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-800">{activity.action}</p>
                      <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                        <Clock size={12} />
                        {activity.time}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h3 className="font-bold text-gray-800 mb-4">إجراءات سريعة</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                <Users size={20} className="text-primary" />
                <span className="text-gray-700">إدارة المستخدمين</span>
              </button>
              <button className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                <Route size={20} className="text-secondary" />
                <span className="text-gray-700">مراجعة الخطوط</span>
              </button>
              <button className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                <Flag size={20} className="text-orange-500" />
                <span className="text-gray-700">عرض التقارير</span>
              </button>
              <button className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                <Settings size={20} className="text-gray-500" />
                <span className="text-gray-700">إعدادات المنصة</span>
              </button>
            </div>
          </div>

          {/* System Health */}
          <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-5 text-white">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <TrendingUp size={20} />
              حالة النظام
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">الخوادم</span>
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>فعالة</span>
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-300">قاعدة البيانات</span>
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>فعالة</span>
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-300">وقت الاستجابة</span>
                <span className="font-medium">45ms</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-300">التوفر</span>
                <span className="font-medium">99.9%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}