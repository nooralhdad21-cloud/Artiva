import React, { useState } from 'react';
import {
  BookOpen,
  FileText,
  Video,
  FileQuestion,
  Download,
  Upload,
  Search,
  Filter,
  ChevronLeft,
  FolderOpen,
  MoreVertical,
  Eye,
  Clock,
  User,
} from 'lucide-react';
import { resources, courses } from '../data/mockData';
import { useApp } from '../context/AppContext';
import { Resource } from '../types';

const resourceTypeIcons = {
  notes: <FileText size={20} className="text-primary" />,
  pdf: <BookOpen size={20} className="text-red-500" />,
  video: <Video size={20} className="text-purple-500" />,
  exam: <FileQuestion size={20} className="text-green-500" />,
  other: <FolderOpen size={20} className="text-gray-500" />,
};

const resourceTypeColors = {
  notes: 'bg-primary/10',
  pdf: 'bg-red-100',
  video: 'bg-purple-100',
  exam: 'bg-green-100',
  other: 'bg-gray-100',
};

export default function Resources() {
  const { user } = useApp();
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const filteredResources = resources.filter(resource => {
    const matchesCourse = !selectedCourse || resource.courseId === selectedCourse;
    const matchesSearch = !searchQuery || resource.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = !selectedType || resource.type === selectedType;
    return matchesCourse && matchesSearch && matchesType;
  });

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('ar-IQ', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">المصادر التعليمية</h1>
          <p className="text-gray-500 text-sm">ملازم، ملفات، أسئلة وزارية</p>
        </div>
        <button className="flex items-center gap-2 px-5 py-2.5 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-all shadow-lg shadow-primary/30">
          <Upload size={20} />
          <span>رفع ملف</span>
        </button>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="ابحث عن ملزمة أو ملف..."
            className="w-full pr-10 pl-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
        </div>
        <div className="flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedType(null)}
            className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
              !selectedType
                ? 'bg-primary text-white'
                : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}
          >
            الكل
          </button>
          {Object.entries(resourceTypeIcons).map(([type, icon]) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all flex items-center gap-2 ${
                selectedType === type
                  ? 'bg-primary text-white'
                  : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {icon}
              <span className="capitalize">
                {type === 'notes' ? 'ملازم' : type === 'pdf' ? 'PDF' : type === 'video' ? 'فيديو' : type === 'exam' ? 'أسئلة' : 'أخرى'}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-6">
        {/* Course Sidebar */}
        <div className="w-64 flex-shrink-0 hidden lg:block">
          <div className="bg-white rounded-2xl shadow-sm p-4">
            <h3 className="font-bold text-gray-800 mb-4">المواد</h3>
            <div className="space-y-2">
              <button
                onClick={() => setSelectedCourse(null)}
                className={`w-full text-right px-4 py-3 rounded-xl transition-all flex items-center gap-3 ${
                  !selectedCourse
                    ? 'bg-primary text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <FolderOpen size={20} />
                <span>كل المواد</span>
              </button>
              {courses.map(course => (
                <button
                  key={course.id}
                  onClick={() => setSelectedCourse(course.id)}
                  className={`w-full text-right px-4 py-3 rounded-xl transition-all flex items-center gap-3 ${
                    selectedCourse === course.id
                      ? 'bg-primary text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <BookOpen size={20} />
                  <div className="flex-1 min-w-0">
                    <span className="block truncate">{course.name}</span>
                    <span className="text-xs opacity-70">{course.year}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Resources Grid */}
        <div className="flex-1">
          {selectedCourse && (
            <div className="mb-4 flex items-center gap-2">
              <button
                onClick={() => setSelectedCourse(null)}
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <ChevronLeft size={20} />
              </button>
              <span className="font-medium text-gray-800">
                {courses.find(c => c.id === selectedCourse)?.name}
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredResources.map(resource => (
              <div
                key={resource.id}
                className="bg-white rounded-2xl shadow-sm p-5 hover:shadow-md transition-all group"
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${resourceTypeColors[resource.type]}`}>
                    {resourceTypeIcons[resource.type]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-gray-800 mb-1 truncate">{resource.title}</h4>
                    <p className="text-sm text-gray-500 mb-2">{resource.courseName}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-400">
                      <span className="flex items-center gap-1">
                        <User size={14} />
                        {resource.uploader.name}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={14} />
                        {formatDate(resource.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Download size={16} />
                    <span>{resource.downloads}</span>
                    <span className="text-gray-300">|</span>
                    <span>{resource.fileSize}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Eye size={18} className="text-gray-500" />
                    </button>
                    <button className="p-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                      <Download size={18} />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <MoreVertical size={18} className="text-gray-500" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {filteredResources.length === 0 && (
            <div className="text-center py-12">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                <BookOpen size={40} className="text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">لا توجد مصادر</h3>
              <p className="text-gray-500 mb-4">ابحث في مادة أخرى أو ارفع ملف جديد</p>
              <button className="px-6 py-2.5 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-all">
                رفع ملف
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}